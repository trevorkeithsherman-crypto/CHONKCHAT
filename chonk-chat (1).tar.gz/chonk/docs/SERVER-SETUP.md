# Running chonk.chat for real

chonk is three pieces:

```
┌──────────────┐   ┌──────────────┐   ┌────────────────────────────────────┐
│ Windows app  │   │ Web / PWA    │   │ YOUR SERVER  (one VPS, one domain) │
│ (Electron)   │──▶│ (this repo)  │──▶│  Caddy (TLS)                       │
└──────────────┘   └──────────────┘   │   ├─ /        → chonk web client    │
                                      │   ├─ /api     → Stoat API (Rust)    │
      both clients are the same        │   ├─ /ws      → events (websocket)  │
      code — the desktop app just      │   ├─ /autumn  → file server (gifs!) │
      wraps the web build              │   ├─ /january → link previews       │
                                      │   └─ /livekit → voice               │
                                      │  MongoDB · Redis · MinIO · RabbitMQ  │
                                      └────────────────────────────────────┘
```

Everything lives under **one domain** (`chonk.chat`). The API is `https://chonk.chat/api`,
the websocket is `wss://chonk.chat/ws`, uploaded GIFs come from `https://chonk.chat/autumn/…`.
The client discovers all of that by calling `GET /api/` once at startup, so the only
thing you ever configure in the client is the API URL.

## 1. Get a box

- Any Ubuntu 22.04/24.04 VPS. **2 vCPU / 4 GB RAM / 40 GB SSD** is comfortable for a few
  thousand users (Hetzner CX22, DigitalOcean $24, etc.). 2 GB works but MongoDB + LiveKit
  get tight.
- Point DNS: `A chonk.chat → <server ip>` (and `www` if you want).
- Open the firewall:

  ```bash
  ufw allow 22/tcp 80/tcp 443/tcp 7881/tcp
  ufw allow 50000:50100/udp      # LiveKit voice — must be direct, not proxied
  ufw enable
  ```

- Install Docker: `curl -fsSL https://get.docker.com | sh`

## 2. Deploy the Stoat backend

```bash
git clone https://github.com/stoatchat/self-hosted stoat && cd stoat
./generate_config.sh chonk.chat      # answer "n" to "behind another reverse proxy?"
```

That writes `Revolt.toml` (hostnames, limits, feature flags) and `secrets.env` (keys).
Two things to change in `Revolt.toml` before first boot:

- **Registration.** Decide whether the instance is open or invite-only:
  ```toml
  [api.registration]
  invite_only = false      # true = you hand out invite codes
  ```
- **Upload limits — this is where GIF avatars live.** Autumn (the file server) has
  per-tag size limits. Raise them so animated avatars and banners aren't rejected:
  ```toml
  [files.limit]
  avatars     = 8000000     # 8 MB
  backgrounds = 12000000    # 12 MB (profile banners)
  icons       = 8000000
  banners     = 12000000
  attachments = 50000000
  ```
  (Field names follow the generated file; keep whatever structure the script gives you
  and just bump the numbers.)
- **Email.** If you want verification emails, fill in the `[api.smtp]` block; otherwise
  leave it and accounts are usable immediately.

Then:

```bash
docker compose up -d
docker compose logs -f api      # wait for "listening"
```

Caddy gets a Let's Encrypt cert automatically. At this point `https://chonk.chat` shows
Stoat's stock web client — we're about to replace it.

## 3. Swap in the chonk client

Stoat's compose file has a `web` service on port 5000 that Caddy routes `/` to. Override
it with the chonk image. In the `stoat/` folder create `compose.override.yml`:

```yaml
services:
  web:
    image: ghcr.io/YOUR_GH_USER/chonk-web:latest   # or build locally, see below
    build:
      context: ../chonk                            # path to this repo
      dockerfile: docker/Dockerfile
      args:
        VITE_API_URL: https://chonk.chat/api
    ports: []                                       # Caddy talks to it internally
    environment: {}
```

Because our nginx listens on **80** and Stoat's web service is expected on **5000**, also
add to the same file:

```yaml
    command: ["nginx", "-g", "daemon off;"]
    expose: ["80"]
```

and in the `Caddyfile`, change the catch-all upstream from `web:5000` to `web:80`. Then:

```bash
docker compose up -d --build web
```

Reload `https://chonk.chat` — it's chonk now. Sign up, upload a GIF avatar, done.

## 4. First admin

Stoat has no "admin user" concept in the client; moderation is per-den via roles.
Instance-level admin (banning accounts, deleting servers) is done with the
[service-admin-panel](https://github.com/stoatchat/service-admin-panel), which reads
the same MongoDB. Add it to the compose file when you need it.

## 5. Clients

| Client | How it finds the server |
|---|---|
| **Web** `https://chonk.chat` | Built with `VITE_API_URL=https://chonk.chat/api` — baked in. |
| **PWA** | Same page; Chrome/Edge show "Install chonk" (manifest + service worker are in `public/`). |
| **Windows app** | `npm run dist:win` → `desktop/build/chonk-setup-x.y.z.exe` (~3 MB). Per-user NSIS installer: no admin prompt, installs to `%LOCALAPPDATA%\Programs\chonk`, Start-menu + desktop shortcut, uninstall from Settings › Apps. Uses the system WebView2 runtime (built into Windows 11 / current Windows 10; the installer offers Microsoft's 2 MB bootstrapper if it's missing). Defaults to `https://chonk.chat/api`; users can point it elsewhere from the login screen ("server" disclosure). |
| **macOS / Linux** | `cd desktop && go build` — same shell on WebKit. |

The desktop build isn't code-signed yet. Windows SmartScreen will show "unknown publisher"
until you sign it (Azure Trusted Signing is the cheap route). Sign both `chonk.exe` and the
installer with `signtool` at the end of `scripts/build-win.sh` when you have a cert.

## 6. Updates & backups

- **Backend:** `cd stoat && git pull && ./generate_config.sh --overwrite chonk.chat && docker compose pull && docker compose up -d`
- **Client:** rebuild the `web` image and `docker compose up -d --build web`. Desktop users
  get a new installer (in-app update check against GitHub Releases is a small follow-up).
- **Backups:** the `mongo` and `minio` volumes are the whole state. `docker compose exec mongo mongodump --archive > backup-$(date +%F).archive` nightly, and rsync the MinIO data dir.

## 7. What it costs

| | |
|---|---|
| VPS | $12–25/mo |
| Domain | already yours |
| TLS | free (Caddy / Let's Encrypt) |
| Object storage | included (MinIO on the box) — move to S3/R2 when uploads outgrow the disk |
| Code signing | $0 until you want SmartScreen quiet |
