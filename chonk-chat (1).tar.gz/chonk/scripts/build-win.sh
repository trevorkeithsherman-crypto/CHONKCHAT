#!/usr/bin/env bash
# Builds the Windows desktop app + per-user installer.
# Works on Linux (cross-compile with mingw-w64 + nsis) and on Windows (MSYS2/Git Bash with mingw + nsis).
set -euo pipefail
cd "$(dirname "$0")/.."
VERSION=$(node -p "require('./package.json').version")

npm run build
rm -rf desktop/dist && cp -r dist desktop/dist

cd desktop
if command -v x86_64-w64-mingw32-gcc >/dev/null; then CC=x86_64-w64-mingw32-gcc; CXX=x86_64-w64-mingw32-g++; else CC=gcc; CXX=g++; fi
[ -f rsrc_windows_amd64.syso ] || "$(go env GOPATH)/bin/rsrc" -ico icon.ico -manifest app.manifest -arch amd64 -o rsrc_windows_amd64.syso

CGO_ENABLED=1 GOOS=windows GOARCH=amd64 CC=$CC CXX=$CXX \
CGO_CXXFLAGS="-I$PWD/mingw-shim -std=c++17" \
go build -trimpath -ldflags "-H windowsgui -s -w -X main.version=$VERSION" -o chonk.exe .

mkdir -p build
makensis -V2 -DVERSION="$VERSION" installer.nsi
echo "→ desktop/build/chonk-setup-$VERSION.exe ($(du -h build/chonk-setup-$VERSION.exe | cut -f1))"
