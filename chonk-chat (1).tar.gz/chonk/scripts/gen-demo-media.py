"""Generate demo avatars / icons / banners (PNG static + GIF animated).
Original little blob characters — squishy, bouncy, chunky outlines.
Run: python3 scripts/gen-demo-media.py
"""
from PIL import Image, ImageDraw
import math, os, random

OUT = os.path.join(os.path.dirname(__file__), "..", "public", "demo-media")
S = 256  # avatar size
FRAMES = 18

PALETTES = {
    "me": ("#ff4fa3", "#ffc233", "#1f1235"),
    "0a": ("#4fd1ff", "#ff4fa3", "#1f1235"),
    "0b": ("#ffc233", "#ff7a1a", "#1f1235"),
    "0c": ("#a78bfa", "#4ade80", "#1f1235"),
    "0d": ("#3ddc84", "#ffd166", "#0b3b36"),
    "0e": ("#ff6b6b", "#ffd166", "#1f1235"),
    "0f": ("#8bac0f", "#dfe8b6", "#0f380f"),
    "0g": ("#ff7a1a", "#ff3d8a", "#160726"),
}

def blob_frame(t, body, cheek, ink, bg, size=S, style=0):
    """One frame of a squishy blob. t in [0,1)."""
    im = Image.new("RGBA", (size, size), bg)
    d = ImageDraw.Draw(im)
    cx, cy = size / 2, size * 0.56
    bounce = math.sin(t * 2 * math.pi)
    squish = 1 + 0.08 * bounce
    w = size * 0.36 * squish
    h = size * 0.34 / squish
    y = cy - size * 0.05 * max(0, bounce)
    lw = max(4, size // 32)
    # shadow (hard offset)
    d.ellipse([cx - w + lw * 1.5, y - h + lw * 1.5, cx + w + lw * 1.5, y + h + lw * 1.5], fill=ink)
    # body
    d.ellipse([cx - w, y - h, cx + w, y + h], fill=body, outline=ink, width=lw)
    # ears / horns by style
    if style % 3 == 1:
        for sx in (-1, 1):
            ex = cx + sx * w * 0.6
            d.polygon([(ex - size*0.07, y - h*0.6), (ex + size*0.07, y - h*0.6), (ex, y - h - size*0.14)], fill=body, outline=ink)
    if style % 3 == 2:
        d.ellipse([cx - size*0.07, y - h - size*0.16, cx + size*0.07, y - h - size*0.02], fill=cheek, outline=ink, width=lw//2)
    # cheeks
    d.ellipse([cx - w*0.72, y + h*0.05, cx - w*0.42, y + h*0.35], fill=cheek)
    d.ellipse([cx + w*0.42, y + h*0.05, cx + w*0.72, y + h*0.35], fill=cheek)
    # eyes (blink near t≈0.5)
    blink = abs(t - 0.5) < 0.06
    for sx in (-1, 1):
        ex = cx + sx * w * 0.32
        ey = y - h * 0.15
        r = size * 0.045
        if blink:
            d.line([ex - r, ey, ex + r, ey], fill=ink, width=lw)
        else:
            d.ellipse([ex - r, ey - r, ex + r, ey + r], fill=ink)
            d.ellipse([ex - r*0.4 + r*0.3, ey - r*0.7, ex + r*0.2 + r*0.3, ey - r*0.1], fill="white")
    # mouth
    mw = size * 0.08
    d.arc([cx - mw, y + h*0.05, cx + mw, y + h*0.45], 10, 170, fill=ink, width=lw//2 + 1)
    return im

def save_avatar(name, pal, style):
    body, cheek, ink = pal
    bg = (0, 0, 0, 0)
    frames = [blob_frame(i / FRAMES, body, cheek, ink, bg, style=style) for i in range(FRAMES)]
    static = frames[0].convert("RGB")
    # give static a soft bg so PNG isn't transparent-on-dark weirdness
    static_bg = Image.new("RGB", (S, S), cheek)
    static_bg.paste(frames[0], mask=frames[0])
    static_bg.save(os.path.join(OUT, "avatars", f"{name}.png"))
    gif_frames = []
    for f in frames:
        g = Image.new("RGB", (S, S), cheek)
        g.paste(f, mask=f)
        gif_frames.append(g.convert("P", palette=Image.ADAPTIVE, colors=64))
    gif_frames[0].save(os.path.join(OUT, "avatars", f"{name}.gif"), save_all=True, append_images=gif_frames[1:], duration=60, loop=0)

def save_icon(name, pal, glyph_fn, animate=True):
    body, cheek, ink = pal
    frames = []
    for i in range(FRAMES if animate else 1):
        t = i / FRAMES
        im = Image.new("RGB", (S, S), body)
        d = ImageDraw.Draw(im)
        glyph_fn(d, t, ink, cheek)
        frames.append(im)
    frames[0].save(os.path.join(OUT, "icons", f"{name}.png"))
    if animate:
        p = [f.convert("P", palette=Image.ADAPTIVE, colors=64) for f in frames]
        p[0].save(os.path.join(OUT, "icons", f"{name}.gif"), save_all=True, append_images=p[1:], duration=70, loop=0)

def glyph_chonk(d, t, ink, cheek):
    # a bouncing blob
    im = blob_frame(t, cheek, "#ffffff", ink, (0,0,0,0), size=S, style=0)
    d._image.paste(im, mask=im)

def glyph_frog(d, t, ink, cheek):
    cx, cy = S/2, S*0.58
    r = S*0.3
    d.ellipse([cx-r, cy-r*0.8, cx+r, cy+r*0.8], fill=cheek, outline=ink, width=8)
    for sx in (-1, 1):
        ex = cx + sx*r*0.55; ey = cy - r*0.8
        d.ellipse([ex-S*0.11, ey-S*0.11, ex+S*0.11, ey+S*0.11], fill=cheek, outline=ink, width=8)
        d.ellipse([ex-S*0.05, ey-S*0.05, ex+S*0.05, ey+S*0.05], fill=ink)
    # blink
    d.arc([cx-r*0.5, cy-r*0.1, cx+r*0.5, cy+r*0.5], 10, 170, fill=ink, width=8)
    # hat that bobs
    bob = math.sin(t*2*math.pi)*4
    d.rectangle([cx-S*0.12, cy-r*1.35+bob, cx+S*0.12, cy-r*1.05+bob], fill=ink)
    d.rectangle([cx-S*0.2, cy-r*1.08+bob, cx+S*0.2, cy-r*1.0+bob], fill=ink)

def glyph_games(d, t, ink, cheek):
    # a chunky d-pad
    cx, cy = S/2, S/2
    a = S*0.1
    d.rounded_rectangle([cx-a, cy-3*a, cx+a, cy+3*a], radius=12, fill=cheek, outline=ink, width=8)
    d.rounded_rectangle([cx-3*a, cy-a, cx+3*a, cy+a], radius=12, fill=cheek, outline=ink, width=8)
    d.rectangle([cx-a+8, cy-a+8, cx+a-8, cy+a-8], fill=cheek)

def save_banner(name, colors, animate=True):
    W, H = 900, 300
    frames = []
    n = FRAMES if animate else 1
    for i in range(n):
        t = i / n
        im = Image.new("RGB", (W, H), colors[0])
        d = ImageDraw.Draw(im)
        # rolling stripes
        for k in range(-3, 14):
            x = k * 120 + (t * 120)
            d.polygon([(x, 0), (x+60, 0), (x-60+60, H), (x-120+60, H)], fill=colors[1] if k % 2 else colors[0])
        # bobbing shapes
        for k in range(6):
            x = 90 + k*150
            y = H*0.55 + math.sin(t*2*math.pi + k)*18
            r = 42
            d.ellipse([x-r+6, y-r+6, x+r+6, y+r+6], fill=colors[3])
            d.ellipse([x-r, y-r, x+r, y+r], fill=colors[2], outline=colors[3], width=6)
        frames.append(im)
    frames[0].save(os.path.join(OUT, "banners", f"{name}.png"))
    if animate:
        p = [f.convert("P", palette=Image.ADAPTIVE, colors=32) for f in frames]
        p[0].save(os.path.join(OUT, "banners", f"{name}.gif"), save_all=True, append_images=p[1:], duration=80, loop=0)

if __name__ == "__main__":
    for sub in ("avatars", "icons", "banners"):
        os.makedirs(os.path.join(OUT, sub), exist_ok=True)
    for i, (name, pal) in enumerate(PALETTES.items()):
        save_avatar(name, pal, style=i)
    save_icon("chonk", ("#ffc233", "#ff4fa3", "#1f1235"), glyph_chonk)
    save_icon("frogs", ("#dff7ff", "#4ade80", "#0b3b36"), glyph_frog)
    save_icon("games", ("#a78bfa", "#ffd166", "#1f1235"), glyph_games, animate=False)
    save_banner("chonk", ("#ff4fa3", "#ff6fb5", "#ffc233", "#1f1235"))
    save_banner("me", ("#4fd1ff", "#7fdfff", "#ff4fa3", "#1f1235"))
    save_banner("0a", ("#a78bfa", "#b9a3fb", "#4ade80", "#12101f"))
    print("ok")
