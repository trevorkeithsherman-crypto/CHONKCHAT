module chonk.chat/desktop

go 1.24

require github.com/webview/webview_go v0.0.0-20240831120633-6173450d4dd6
