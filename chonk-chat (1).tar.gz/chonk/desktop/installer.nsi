; chonk — per-user Windows installer (no admin required)
; Build: makensis -DVERSION=0.1.0 installer.nsi

!ifndef VERSION
  !define VERSION "0.0.0"
!endif
!define APPNAME "chonk"
!define PUBLISHER "Trevor Sherman"
!define URL "https://chonk.chat"
!define UNINST_KEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\${APPNAME}"

Unicode true
Name "${APPNAME}"
OutFile "build\chonk-setup-${VERSION}.exe"
InstallDir "$LOCALAPPDATA\Programs\${APPNAME}"
InstallDirRegKey HKCU "Software\${APPNAME}" "InstallDir"
RequestExecutionLevel user        ; <- per-user, no UAC prompt
SetCompressor /SOLID lzma
BrandingText "${APPNAME} ${VERSION}"
Icon "icon.ico"
UninstallIcon "icon.ico"

VIProductVersion "${VERSION}.0"
VIAddVersionKey "ProductName" "${APPNAME}"
VIAddVersionKey "CompanyName" "${PUBLISHER}"
VIAddVersionKey "FileDescription" "${APPNAME} installer"
VIAddVersionKey "FileVersion" "${VERSION}"
VIAddVersionKey "ProductVersion" "${VERSION}"
VIAddVersionKey "LegalCopyright" "© 2026 ${PUBLISHER}"

!include "MUI2.nsh"
!define MUI_ICON "icon.ico"
!define MUI_UNICON "icon.ico"
!define MUI_FINISHPAGE_RUN "$INSTDIR\chonk.exe"
!define MUI_FINISHPAGE_RUN_TEXT "launch ${APPNAME}"
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "English"

Function .onInit
  ; Close a running instance so files can be replaced.
  nsExec::ExecToStack 'taskkill /IM chonk.exe /F'
  Pop $0
FunctionEnd

Section "install"
  SetOutPath "$INSTDIR"
  File "chonk.exe"
  File "icon.ico"

  WriteUninstaller "$INSTDIR\uninstall.exe"
  WriteRegStr HKCU "Software\${APPNAME}" "InstallDir" "$INSTDIR"

  ; Start menu + desktop shortcuts
  CreateShortcut "$SMPROGRAMS\${APPNAME}.lnk" "$INSTDIR\chonk.exe" "" "$INSTDIR\icon.ico"
  CreateShortcut "$DESKTOP\${APPNAME}.lnk"    "$INSTDIR\chonk.exe" "" "$INSTDIR\icon.ico"

  ; Settings > Apps entry (per-user)
  WriteRegStr   HKCU "${UNINST_KEY}" "DisplayName"     "${APPNAME}"
  WriteRegStr   HKCU "${UNINST_KEY}" "DisplayVersion"  "${VERSION}"
  WriteRegStr   HKCU "${UNINST_KEY}" "Publisher"       "${PUBLISHER}"
  WriteRegStr   HKCU "${UNINST_KEY}" "URLInfoAbout"    "${URL}"
  WriteRegStr   HKCU "${UNINST_KEY}" "DisplayIcon"     "$INSTDIR\icon.ico"
  WriteRegStr   HKCU "${UNINST_KEY}" "InstallLocation" "$INSTDIR"
  WriteRegStr   HKCU "${UNINST_KEY}" "UninstallString" '"$INSTDIR\uninstall.exe"'
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoModify" 1
  WriteRegDWORD HKCU "${UNINST_KEY}" "NoRepair" 1

  ; WebView2 runtime check — present on Windows 11 and up-to-date Windows 10.
  ; If it's missing, hand the user Microsoft's tiny bootstrapper.
  ClearErrors
  ReadRegStr $0 HKCU "Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" "pv"
  IfErrors 0 webview_ok
  ReadRegStr $0 HKLM "SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" "pv"
  IfErrors 0 webview_ok
  MessageBox MB_YESNO|MB_ICONINFORMATION "${APPNAME} needs the Microsoft WebView2 runtime (free, ~2 MB download). Open the download page now?" IDNO webview_ok
  ExecShell "open" "https://go.microsoft.com/fwlink/p/?LinkId=2124703"
webview_ok:
SectionEnd

Section "uninstall"
  nsExec::ExecToStack 'taskkill /IM chonk.exe /F'
  Pop $0
  Delete "$INSTDIR\chonk.exe"
  Delete "$INSTDIR\icon.ico"
  Delete "$INSTDIR\uninstall.exe"
  RMDir "$INSTDIR"
  Delete "$SMPROGRAMS\${APPNAME}.lnk"
  Delete "$DESKTOP\${APPNAME}.lnk"
  DeleteRegKey HKCU "${UNINST_KEY}"
  DeleteRegKey HKCU "Software\${APPNAME}"
  ; WebView2 user data lives next to the exe; clear it too
  RMDir /r "$INSTDIR\chonk.exe.WebView2"
SectionEnd
