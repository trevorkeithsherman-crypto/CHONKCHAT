// chonk desktop — a tiny native shell around the web build.
//
// Uses the OS webview (WebView2 on Windows, WebKit on macOS/Linux) instead of
// bundling a browser, so the installer is a few MB rather than a hundred.
// The built web app (../dist) is embedded in the binary and served from a
// loopback HTTP server; API traffic goes straight to whichever Stoat server
// the user picked on the login screen.
package main

import (
	"embed"
	"fmt"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"path"
	"strings"

	webview "github.com/webview/webview_go"
)

//go:embed all:dist
var dist embed.FS

const appName = "chonk"

func main() {
	sub, err := fs.Sub(dist, "dist")
	if err != nil {
		log.Fatal(err)
	}

	ln, err := net.Listen("tcp", "127.0.0.1:0")
	if err != nil {
		log.Fatal(err)
	}
	addr := ln.Addr().(*net.TCPAddr)

	fileServer := http.FileServer(http.FS(sub))
	mux := http.NewServeMux()
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		// SPA fallback: anything without a file extension gets index.html
		p := path.Clean(r.URL.Path)
		if p != "/" && path.Ext(p) == "" {
			r.URL.Path = "/"
		}
		if strings.HasPrefix(p, "/assets/") {
			w.Header().Set("Cache-Control", "public, max-age=31536000, immutable")
		}
		fileServer.ServeHTTP(w, r)
	})
	go func() { _ = http.Serve(ln, mux) }()

	debug := os.Getenv("CHONK_DEBUG") == "1"
	w := webview.New(debug)
	defer w.Destroy()
	w.SetTitle(appName)
	w.SetSize(1280, 820, webview.HintNone)
	w.SetSize(720, 480, webview.HintMin)

	// Tell the page it's inside the desktop shell, and give it a way to open
	// external links in the system browser.
	w.Init(`window.chonkDesktop = { platform: "` + platform() + `", version: "` + version + `" };`)
	_ = w.Bind("chonkOpenExternal", func(url string) {
		if strings.HasPrefix(url, "http://") || strings.HasPrefix(url, "https://") {
			openBrowser(url)
		}
	})

	w.Navigate(fmt.Sprintf("http://127.0.0.1:%d/", addr.Port))
	w.Run()
}

var version = "dev" // overridden with -ldflags "-X main.version=x.y.z"
