// MinGW lacks EventToken.h (it ships with the Windows SDK). WebView2.h only
// needs this one struct from it.
#ifndef __eventtoken_h__
#define __eventtoken_h__
typedef struct EventRegistrationToken {
  __int64 value;
} EventRegistrationToken;
#endif
