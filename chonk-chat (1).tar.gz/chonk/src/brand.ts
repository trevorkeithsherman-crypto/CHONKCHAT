/**
 * Brand config — swap these to rebrand the whole client.
 */
export const brand = {
  name: "chonk",
  domain: "chonk.chat",
  tagline: "big rooms. little friends. zero corporate beige.",
  /** Shown while connecting / loading */
  loadingLines: [
    "fluffing the pillows…",
    "warming up the chonk…",
    "feeding the hamsters…",
    "untangling the wires…",
    "counting the snacks…",
  ],
  /** Word used for a "server" in the UI */
  serverWord: "den",
  serverWordPlural: "dens",
  /** Word used for a "channel" in the UI */
  channelWord: "room",
};

export type Brand = typeof brand;
