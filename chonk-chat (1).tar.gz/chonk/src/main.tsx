/* @refresh reload */
import { render } from "solid-js/web";
import { Router, Route } from "@solidjs/router";
import "./styles/global.css";
import App from "./App";
import Login from "./pages/Login";
import Shell from "./pages/Shell";
import Home from "./pages/Home";
import ChannelPage from "./pages/ChannelPage";
import { boot } from "./lib/client";

boot();

render(
  () => (
    <Router root={App}>
      <Route path="/login" component={Login} />
      <Route path="/app" component={Shell}>
        <Route path="/" component={Home} />
        <Route path="/den/:server/:channel?" component={ChannelPage} />
        <Route path="/dm/:channel" component={ChannelPage} />
      </Route>
      <Route path="*" component={Home} />
    </Router>
  ),
  document.getElementById("root")!,
);
