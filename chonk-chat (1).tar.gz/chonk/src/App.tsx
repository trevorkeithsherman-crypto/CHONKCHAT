import { createEffect, Show, type ParentProps } from "solid-js";
import { useLocation, useNavigate } from "@solidjs/router";
import { ThemeProvider } from "./theme/ThemeProvider";
import { appState } from "./lib/client";
import Loading from "./components/Loading";

export default function App(props: ParentProps) {
  const navigate = useNavigate();
  const location = useLocation();

  // Route guard: bounce between /login and /app based on connection state.
  createEffect(() => {
    const s = appState();
    const onLogin = location.pathname.startsWith("/login");
    const onApp = location.pathname.startsWith("/app");
    if (s === "logged-out" && !onLogin) navigate("/login", { replace: true });
    if (s === "ready" && !onApp) navigate("/app", { replace: true });
  });

  return (
    <ThemeProvider>
      <Show when={appState() !== "boot" && appState() !== "connecting"} fallback={<Loading />}>
        {props.children}
      </Show>
    </ThemeProvider>
  );
}
