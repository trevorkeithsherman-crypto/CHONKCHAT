/**
 * Theme engine — every visual decision in the app resolves to one of these tokens,
 * exposed as CSS custom properties on <html>. Presets are plain objects, so users
 * can fork one, tweak it in the editor, and export/import as JSON.
 */
export type ThemeTokens = {
  /** page background */
  bg: string;
  /** primary panel surface (sidebars, cards) */
  surface: string;
  /** secondary/raised surface (hover, inputs) */
  surface2: string;
  /** text + outlines ("ink") */
  ink: string;
  /** muted text */
  inkMuted: string;
  /** border/outline colour for the chunky sticker look */
  line: string;
  /** primary accent (buttons, active states) */
  accent: string;
  /** secondary accent (highlights, badges) */
  accent2: string;
  /** tertiary accent (mentions, fun bits) */
  accent3: string;
  /** text colour to sit on accent */
  onAccent: string;
  danger: string;
  success: string;
  /** base corner radius in px */
  radius: number;
  /** outline width in px (0 = flat) */
  lineWidth: number;
  /** hard offset shadow distance in px (0 = none) */
  shadow: number;
  /** display/heading font stack */
  fontDisplay: string;
  /** body font stack */
  fontBody: string;
  /** motion multiplier: 0 = reduced, 1 = normal, 1.5 = extra bouncy */
  motion: number;
  /** optional wallpaper (url or css gradient) behind the chat */
  wallpaper?: string;
  /** optional pattern overlay opacity 0-1 */
  patternOpacity?: number;
  /** light or dark scheme (for native controls / scrollbars) */
  scheme: "light" | "dark";
};

export type Theme = {
  id: string;
  name: string;
  emoji: string;
  description: string;
  tokens: ThemeTokens;
  builtin?: boolean;
};

const displayRetro = `"Fredoka", "Nunito", system-ui, sans-serif`;
const bodyRetro = `"Nunito", system-ui, -apple-system, sans-serif`;
const mono = `"Space Mono", ui-monospace, monospace`;

const base: Omit<ThemeTokens, "bg" | "surface" | "surface2" | "ink" | "inkMuted" | "line" | "accent" | "accent2" | "accent3" | "onAccent" | "scheme"> = {
  danger: "#ff4d6d",
  success: "#3ddc84",
  radius: 18,
  lineWidth: 3,
  shadow: 4,
  fontDisplay: displayRetro,
  fontBody: bodyRetro,
  motion: 1,
  patternOpacity: 0.06,
};

export const themes: Theme[] = [
  {
    id: "bubblegum",
    name: "Bubblegum Arcade",
    emoji: "🍬",
    description: "Cream paper, hot pink and butter yellow. Stickers everywhere.",
    builtin: true,
    tokens: {
      ...base,
      scheme: "light",
      bg: "#fff4d6",
      surface: "#ffffff",
      surface2: "#fff0f5",
      ink: "#1f1235",
      inkMuted: "#6d5f85",
      line: "#1f1235",
      accent: "#ff4fa3",
      accent2: "#ffc233",
      accent3: "#4fd1ff",
      onAccent: "#1f1235",
      wallpaper: "radial-gradient(circle at 20% 10%, #ffe1f0 0, transparent 40%), radial-gradient(circle at 90% 80%, #dff7ff 0, transparent 45%)",
    },
  },
  {
    id: "midnight-cabinet",
    name: "Midnight Cabinet",
    emoji: "🕹️",
    description: "Dark arcade cabinet with neon edges. Default for night owls.",
    builtin: true,
    tokens: {
      ...base,
      scheme: "dark",
      bg: "#12101f",
      surface: "#1c1830",
      surface2: "#27223f",
      ink: "#f5f0ff",
      inkMuted: "#a99cc9",
      line: "#0a0814",
      accent: "#a78bfa",
      accent2: "#ffd166",
      accent3: "#4ade80",
      onAccent: "#12101f",
      wallpaper: "radial-gradient(circle at 80% 0%, #2d2450 0, transparent 45%), radial-gradient(circle at 0% 100%, #1e2a4a 0, transparent 45%)",
      patternOpacity: 0.08,
    },
  },
  {
    id: "gameboy",
    name: "Pocket Handheld",
    emoji: "🟩",
    description: "Four shades of green and a whole lot of nostalgia.",
    builtin: true,
    tokens: {
      ...base,
      scheme: "light",
      bg: "#c4cfa1",
      surface: "#dfe8b6",
      surface2: "#b7c58f",
      ink: "#0f380f",
      inkMuted: "#306230",
      line: "#0f380f",
      accent: "#306230",
      accent2: "#8bac0f",
      accent3: "#9bbc0f",
      onAccent: "#dfe8b6",
      radius: 8,
      shadow: 3,
      fontDisplay: mono,
      fontBody: mono,
      wallpaper: "none",
      patternOpacity: 0.12,
    },
  },
  {
    id: "sunset-cassette",
    name: "Sunset Cassette",
    emoji: "📼",
    description: "Orange, magenta and deep violet. Side B forever.",
    builtin: true,
    tokens: {
      ...base,
      scheme: "dark",
      bg: "#2a1140",
      surface: "#3a1a58",
      surface2: "#4c2570",
      ink: "#fff3e0",
      inkMuted: "#d7b8e8",
      line: "#160726",
      accent: "#ff7a1a",
      accent2: "#ff3d8a",
      accent3: "#ffd23f",
      onAccent: "#2a1140",
      wallpaper: "linear-gradient(180deg, #2a1140 0%, #4a1c5c 60%, #7a2a4a 100%)",
    },
  },
  {
    id: "paper-zine",
    name: "Paper Zine",
    emoji: "📰",
    description: "Photocopied black-and-white with one loud red. Very DIY.",
    builtin: true,
    tokens: {
      ...base,
      scheme: "light",
      bg: "#f4f1ea",
      surface: "#fffdf7",
      surface2: "#ebe6da",
      ink: "#111111",
      inkMuted: "#5c5852",
      line: "#111111",
      accent: "#e63946",
      accent2: "#111111",
      accent3: "#f4a261",
      onAccent: "#fffdf7",
      radius: 6,
      lineWidth: 2,
      shadow: 5,
      wallpaper: "none",
      patternOpacity: 0.1,
    },
  },
  {
    id: "seafoam",
    name: "Seafoam Motel",
    emoji: "🏝️",
    description: "Mint, coral and cream. Retro roadside sign energy.",
    builtin: true,
    tokens: {
      ...base,
      scheme: "light",
      bg: "#d9f5ec",
      surface: "#ffffff",
      surface2: "#eafaf4",
      ink: "#0b3b36",
      inkMuted: "#4f7a74",
      line: "#0b3b36",
      accent: "#ff6b6b",
      accent2: "#ffd166",
      accent3: "#06d6a0",
      onAccent: "#ffffff",
      radius: 24,
      wallpaper: "radial-gradient(circle at 50% -20%, #ffffff 0, transparent 50%)",
    },
  },
];

export const defaultThemeId = "bubblegum";

export function getTheme(id: string): Theme {
  return themes.find((t) => t.id === id) ?? themes[0];
}

/** Turn tokens into CSS custom properties. */
export function tokensToCSSVars(t: ThemeTokens): Record<string, string> {
  return {
    "--bg": t.bg,
    "--surface": t.surface,
    "--surface-2": t.surface2,
    "--ink": t.ink,
    "--ink-muted": t.inkMuted,
    "--line": t.line,
    "--accent": t.accent,
    "--accent-2": t.accent2,
    "--accent-3": t.accent3,
    "--on-accent": t.onAccent,
    "--danger": t.danger,
    "--success": t.success,
    "--radius": `${t.radius}px`,
    "--radius-sm": `${Math.max(4, Math.round(t.radius * 0.5))}px`,
    "--radius-lg": `${Math.round(t.radius * 1.5)}px`,
    "--line-w": `${t.lineWidth}px`,
    "--shadow-d": `${t.shadow}px`,
    "--font-display": t.fontDisplay,
    "--font-body": t.fontBody,
    "--motion": `${t.motion}`,
    "--wallpaper": t.wallpaper && t.wallpaper !== "none" ? t.wallpaper : "none",
    "--pattern-opacity": `${t.patternOpacity ?? 0}`,
  };
}
