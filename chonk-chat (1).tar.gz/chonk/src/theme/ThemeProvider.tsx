import {
  createContext,
  createEffect,
  createSignal,
  useContext,
  type ParentComponent,
} from "solid-js";
import { createStore, produce } from "solid-js/store";
import {
  defaultThemeId,
  getTheme,
  themes,
  tokensToCSSVars,
  type Theme,
  type ThemeTokens,
} from "./themes";

const STORAGE_KEY = "chonk.theme.v1";

type Persisted = {
  activeId: string;
  custom: Theme[];
};

function load(): Persisted {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch {
    /* ignore */
  }
  return { activeId: defaultThemeId, custom: [] };
}

function save(p: Persisted) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(p));
  } catch {
    /* ignore */
  }
}

type ThemeContextValue = {
  /** all themes: builtin + custom */
  all: () => Theme[];
  active: () => Theme;
  setActive: (id: string) => void;
  /** live-edit the active theme's tokens (creates a custom copy if editing a builtin) */
  patch: (partial: Partial<ThemeTokens>) => void;
  /** duplicate active theme as a new custom theme */
  fork: (name?: string) => Theme;
  remove: (id: string) => void;
  exportJSON: () => string;
  importJSON: (json: string) => Theme | null;
};

const ThemeContext = createContext<ThemeContextValue>();

export const ThemeProvider: ParentComponent = (props) => {
  const initial = load();
  const [state, setState] = createStore<Persisted>(initial);
  const [tick, setTick] = createSignal(0);

  const all = () => {
    tick();
    return [...themes, ...state.custom];
  };

  const active = () => {
    tick();
    return state.custom.find((t) => t.id === state.activeId) ?? getTheme(state.activeId);
  };

  const persist = () => {
    save({ activeId: state.activeId, custom: state.custom });
    setTick((t) => t + 1);
  };

  const setActive = (id: string) => {
    setState("activeId", id);
    persist();
  };

  const fork = (name?: string): Theme => {
    const src = active();
    const id = `custom-${Date.now().toString(36)}`;
    const t: Theme = {
      id,
      name: name ?? `${src.name} (remix)`,
      emoji: "✨",
      description: "Your custom theme",
      tokens: { ...src.tokens },
    };
    setState(produce((s) => s.custom.push(t)));
    setState("activeId", id);
    persist();
    return t;
  };

  const patch = (partial: Partial<ThemeTokens>) => {
    let target = active();
    if (target.builtin) target = fork();
    setState(
      "custom",
      (t) => t.id === target.id,
      "tokens",
      (tok) => ({ ...tok, ...partial }),
    );
    persist();
  };

  const remove = (id: string) => {
    setState(produce((s) => (s.custom = s.custom.filter((t) => t.id !== id))));
    if (state.activeId === id) setState("activeId", defaultThemeId);
    persist();
  };

  const exportJSON = () => JSON.stringify(active(), null, 2);

  const importJSON = (json: string): Theme | null => {
    try {
      const parsed = JSON.parse(json) as Theme;
      if (!parsed?.tokens?.bg) return null;
      const id = `custom-${Date.now().toString(36)}`;
      const t: Theme = { ...parsed, id, builtin: false };
      setState(produce((s) => s.custom.push(t)));
      setState("activeId", id);
      persist();
      return t;
    } catch {
      return null;
    }
  };

  // Apply CSS variables whenever the active theme changes.
  createEffect(() => {
    const t = active();
    const vars = tokensToCSSVars(t.tokens);
    const root = document.documentElement;
    for (const [k, v] of Object.entries(vars)) root.style.setProperty(k, v);
    root.dataset.scheme = t.tokens.scheme;
    root.style.colorScheme = t.tokens.scheme;
    const meta = document.querySelector('meta[name="theme-color"]');
    meta?.setAttribute("content", t.tokens.accent);
  });

  const value: ThemeContextValue = {
    all,
    active,
    setActive,
    patch,
    fork,
    remove,
    exportJSON,
    importJSON,
  };

  return <ThemeContext.Provider value={value}>{props.children}</ThemeContext.Provider>;
};

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error("useTheme outside ThemeProvider");
  return ctx;
}
