import { createStore } from "solid-js/store";

export type Settings = {
  /** when to play animated avatars/banners/icons */
  animate: "always" | "hover" | "never";
  /** message density */
  density: "cozy" | "compact";
  /** show member list */
  showMembers: boolean;
  /** play a tiny pop on send */
  sounds: boolean;
};

const KEY = "chonk.settings.v1";

function load(): Settings {
  const d: Settings = { animate: "hover", density: "cozy", showMembers: true, sounds: true };
  try {
    return { ...d, ...(JSON.parse(localStorage.getItem(KEY) || "{}") as Partial<Settings>) };
  } catch {
    return d;
  }
}

const [settings, setSettingsStore] = createStore<Settings>(load());

export { settings };

export function setSetting<K extends keyof Settings>(key: K, value: Settings[K]) {
  setSettingsStore(key, value);
  try {
    localStorage.setItem(KEY, JSON.stringify(settings));
  } catch {
    /* ignore */
  }
}
