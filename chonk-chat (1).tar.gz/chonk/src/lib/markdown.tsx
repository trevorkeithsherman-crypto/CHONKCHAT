import { For, type JSX } from "solid-js";

/**
 * Tiny, safe markdown-ish renderer: **bold**, *italic*, `code`, ~~strike~~,
 * links, and line breaks. Renders JSX (never innerHTML) so user content can't
 * inject markup.
 */
const TOKEN = /(\*\*[^*]+\*\*|\*[^*]+\*|~~[^~]+~~|`[^`]+`|https?:\/\/[^\s<]+)/g;

/** In the desktop shell, hand http(s) links to the system browser. */
export function openExternal(e: MouseEvent) {
  const fn = (window as unknown as { chonkOpenExternal?: (u: string) => void }).chonkOpenExternal;
  const href = (e.currentTarget as HTMLAnchorElement | null)?.href;
  if (fn && href) {
    e.preventDefault();
    fn(href);
  }
}

export function Markdown(props: { text: string }): JSX.Element {
  const lines = () => props.text.split("\n");
  return (
    <For each={lines()}>
      {(line, i) => (
        <>
          {i() > 0 && <br />}
          <For each={line.split(TOKEN)}>{(part) => <Inline part={part} />}</For>
        </>
      )}
    </For>
  );
}

function Inline(props: { part: string }): JSX.Element {
  const p = props.part;
  if (!p) return null;
  if (p.startsWith("**") && p.endsWith("**")) return <strong>{p.slice(2, -2)}</strong>;
  if (p.startsWith("~~") && p.endsWith("~~")) return <s>{p.slice(2, -2)}</s>;
  if (p.startsWith("`") && p.endsWith("`")) return <code class="md-code mono">{p.slice(1, -1)}</code>;
  if (p.startsWith("*") && p.endsWith("*") && p.length > 2) return <em>{p.slice(1, -1)}</em>;
  if (/^https?:\/\//.test(p))
    return (
      <a href={p} target="_blank" rel="noopener noreferrer nofollow" class="md-link" onClick={openExternal}>
        {p}
      </a>
    );
  return p;
}
