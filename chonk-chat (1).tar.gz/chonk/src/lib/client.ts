import { createSignal } from "solid-js";
import { Client } from "stoat.js";
import type { API } from "stoat.js";
import { bootDemo, DEMO_CONFIG } from "./demo";

export type StoredSession = { _id: string; token: string; user_id: string };

const SESSION_KEY = "chonk.session.v1";
const API_KEY = "chonk.apiUrl";
const DEFAULT_API_URL = import.meta.env.VITE_API_URL || "https://stoat.chat/api";
/** Which Stoat API this client talks to. Users can point it at any self-host. */
export function getApiUrl(): string {
  try {
    return localStorage.getItem(API_KEY) || DEFAULT_API_URL;
  } catch {
    return DEFAULT_API_URL;
  }
}
export function setApiUrl(url: string) {
  const clean = url.trim().replace(/\/+$/, "");
  if (!clean || clean === DEFAULT_API_URL) localStorage.removeItem(API_KEY);
  else localStorage.setItem(API_KEY, clean);
  clearSession();
  location.reload();
}
const API_URL = getApiUrl();
export const IS_DESKTOP = typeof (window as unknown as { chonkDesktop?: unknown }).chonkDesktop !== "undefined";
export const IS_DEMO =
  import.meta.env.VITE_DEMO === "1" ||
  new URLSearchParams(location.search).get("demo") === "1";

export type AppState = "boot" | "logged-out" | "connecting" | "ready" | "error";

const [state, setState] = createSignal<AppState>("boot");
const [error, setError] = createSignal<string | null>(null);
export { state as appState, error as appError };

/** The one client instance for the whole app. */
export const client: Client = IS_DEMO
  ? new Client({ baseURL: "/demo-api", autoReconnect: false }, DEMO_CONFIG)
  : new Client({ baseURL: API_URL });

client.on("ready", () => setState("ready"));
client.on("connecting", () => setState("connecting"));
client.on("error", (e) => {
  console.error(e);
  setError(typeof e === "string" ? e : (e as { type?: string })?.type ?? "Unknown error");
});
client.on("logout", () => {
  clearSession();
  setState("logged-out");
});

function loadSession(): StoredSession | null {
  try {
    const raw = localStorage.getItem(SESSION_KEY);
    return raw ? (JSON.parse(raw) as StoredSession) : null;
  } catch {
    return null;
  }
}
function saveSession(s: StoredSession) {
  localStorage.setItem(SESSION_KEY, JSON.stringify(s));
}
function clearSession() {
  localStorage.removeItem(SESSION_KEY);
}

/** Called once on app start. Resumes a saved session or lands on login. */
export async function boot() {
  if (IS_DEMO) {
    bootDemo(client);
    setState("ready");
    return;
  }
  const saved = loadSession();
  if (!saved) {
    setState("logged-out");
    return;
  }
  try {
    setState("connecting");
    await ensureConfig();
    client.useExistingSession(saved);
    client.connect();
  } catch (e) {
    console.error(e);
    clearSession();
    setState("logged-out");
  }
}

export async function login(email: string, password: string, friendlyName = "chonk web") {
  setError(null);
  setState("connecting");
  try {
    await ensureConfig();
    const data = (await client.api.post("/auth/session/login", {
      email,
      password,
      friendly_name: friendlyName,
    })) as API.ResponseLogin;
    if (data.result !== "Success") {
      throw new Error(data.result === "MFA" ? "MFA is not supported yet" : "Login failed");
    }
    const session: StoredSession = { _id: data._id, token: data.token, user_id: data.user_id };
    saveSession(session);
    client.useExistingSession(session);
    client.connect();
  } catch (e) {
    const msg = extractError(e);
    setError(msg);
    setState("logged-out");
    throw new Error(msg);
  }
}

export async function register(email: string, password: string, inviteCode?: string, captcha?: string) {
  setError(null);
  await ensureConfig();
  await client.account.create({ email, password, invite: inviteCode || undefined, captcha: captcha || undefined });
}

/** hCaptcha site key if the server requires one for sign-up (the public instance does). */
export async function captchaKey(): Promise<string | null> {
  if (IS_DEMO) return null;
  try {
    await ensureConfig();
    const c = client.configuration?.features.captcha;
    return c?.enabled ? c.key : null;
  } catch {
    return null;
  }
}

export async function logout() {
  try {
    if (!IS_DEMO) {
      await client.api.post("/auth/session/logout").catch(() => {});
      client.events.disconnect();
    }
  } finally {
    clearSession();
    setState("logged-out");
    location.href = "/";
  }
}

/** Fetch server config once (the SDK does this lazily; we need it before login). */
async function ensureConfig() {
  if (!client.configuration) client.configuration = await client.api.get("/");
}

function extractError(e: unknown): string {
  if (e instanceof Error) return e.message;
  if (typeof e === "string") return e;
  const o = e as { type?: string; error?: string; data?: { type?: string } };
  return o?.data?.type ?? o?.type ?? o?.error ?? "Something went wrong";
}
