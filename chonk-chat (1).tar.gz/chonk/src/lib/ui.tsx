import { createContext, useContext, type ParentProps } from "solid-js";

type UI = { openSettings: () => void };
const Ctx = createContext<UI>({ openSettings: () => {} });

export function UIProvider(props: ParentProps<{ value: UI }>) {
  return <Ctx.Provider value={props.value}>{props.children}</Ctx.Provider>;
}
export const useUI = () => useContext(Ctx);
