/**
 * Demo mode: hydrates the real stoat.js client with fake data so the entire UI
 * can be explored (and screenshotted) with no backend. Same components, same
 * reactive objects — just no network.
 */
import type { Client, API } from "stoat.js";
import { ulid } from "ulid";

export const DEMO_CONFIG: API.RevoltConfig = {
  revolt: "demo",
  ws: "ws://localhost/demo",
  app: "http://localhost:5173",
  vapid: "",
  features: {
    captcha: { enabled: false, key: "" },
    email: false,
    invite_only: false,
    autumn: { enabled: true, url: "/demo-media" },
    january: { enabled: false, url: "" },
    livekit: { enabled: false, nodes: [] },
  },
  build: {
    commit_sha: "demo",
    commit_timestamp: "",
    semver: "0.0.0",
    origin_url: "",
    timestamp: "",
  },
};

const file = (tag: string, id: string, gif = true): API.File => ({
  _id: id,
  tag,
  filename: `${id}.${gif ? "gif" : "png"}`,
  metadata: { type: "Image", width: 256, height: 256 } as API.File["metadata"],
  content_type: gif ? "image/gif" : "image/png",
  size: 12345,
});

export const DEMO_ME = "01DEMO000000000000000000ME";

type DemoUser = {
  id: string;
  username: string;
  display: string;
  status?: string;
  presence?: API.Presence;
  online?: boolean;
  gif?: boolean;
};

const users: DemoUser[] = [
  { id: DEMO_ME, username: "trevor", display: "Trevor", status: "building chonk 🛠️", presence: "Online", online: true, gif: true },
  { id: "01DEMO0000000000000000000A", username: "pixelpatty", display: "Pixel Patty", status: "drawing frogs", presence: "Online", online: true, gif: true },
  { id: "01DEMO0000000000000000000B", username: "beanbag", display: "beanbag", status: "afk (snacks)", presence: "Idle", online: true, gif: true },
  { id: "01DEMO0000000000000000000C", username: "noodle_dev", display: "Noodle", status: "shipping", presence: "Busy", online: true, gif: false },
  { id: "01DEMO0000000000000000000D", username: "sprocket", display: "Sprocket", presence: "Online", online: true, gif: true },
  { id: "01DEMO0000000000000000000E", username: "moth", display: "moth 🦋", presence: "Focus", online: true, gif: false },
  { id: "01DEMO0000000000000000000F", username: "gooseberry", display: "Gooseberry", online: false, gif: false },
  { id: "01DEMO0000000000000000000G", username: "toasty", display: "toasty", online: false, gif: true },
];

const DEN_CHONK = "01DEMOSERVER000000000CHONK";
const DEN_ART = "01DEMOSERVER0000000000ART0";
const DEN_GAME = "01DEMOSERVER000000000GAMES";

const CH = {
  welcome: "01DEMOCHAN000000000WELCOME",
  general: "01DEMOCHAN000000000GENERAL",
  memes: "01DEMOCHAN00000000000MEMES",
  showcase: "01DEMOCHAN000000000SHOWCAS",
  bugs: "01DEMOCHAN0000000000000BUG",
  voice: "01DEMOCHAN00000000000VOICE",
  sketch: "01DEMOCHAN000000000SKETCH0",
  crit: "01DEMOCHAN000000000000CRIT",
  lfg: "01DEMOCHAN00000000000000LF",
  clips: "01DEMOCHAN0000000000CLIPS0",
  dmPatty: "01DEMODM00000000000000PATT",
};

const servers: API.Server[] = [
  {
    _id: DEN_CHONK,
    owner: DEMO_ME,
    name: "chonk HQ",
    description: "the official den. be nice, post frogs.",
    channels: [CH.welcome, CH.general, CH.memes, CH.showcase, CH.bugs, CH.voice],
    categories: [
      { id: "cat-start", title: "start here", channels: [CH.welcome] },
      { id: "cat-hang", title: "hang out", channels: [CH.general, CH.memes, CH.voice] },
      { id: "cat-build", title: "building", channels: [CH.showcase, CH.bugs] },
    ],
    default_permissions: 0,
    icon: file("icons", "chonk"),
    banner: file("banners", "chonk"),
    roles: {
      "role-admin": { name: "admin", permissions: { a: 0, d: 0 }, colour: "#ff4fa3", rank: 0 },
      "role-artist": { name: "artist", permissions: { a: 0, d: 0 }, colour: "#4fd1ff", rank: 1 },
    },
  },
  {
    _id: DEN_ART,
    owner: "01DEMO0000000000000000000A",
    name: "Frog Drawing Club",
    description: "one frog a day",
    channels: [CH.sketch, CH.crit],
    categories: [{ id: "cat-art", title: "frogs", channels: [CH.sketch, CH.crit] }],
    default_permissions: 0,
    icon: file("icons", "frogs"),
  },
  {
    _id: DEN_GAME,
    owner: "01DEMO0000000000000000000D",
    name: "Couch Co-op",
    channels: [CH.lfg, CH.clips],
    categories: [{ id: "cat-g", title: "games", channels: [CH.lfg, CH.clips] }],
    default_permissions: 0,
    icon: file("icons", "games", false),
  },
];

const text = (id: string, server: string, name: string, description?: string): API.Channel =>
  ({ channel_type: "TextChannel", _id: id, server, name, description }) as API.Channel;

const channels: API.Channel[] = [
  text(CH.welcome, DEN_CHONK, "welcome", "rules, links, and a warm hello"),
  text(CH.general, DEN_CHONK, "general", "talk about literally anything"),
  text(CH.memes, DEN_CHONK, "memes", "gifs only. text is a crime"),
  text(CH.showcase, DEN_CHONK, "showcase", "show off what you made"),
  text(CH.bugs, DEN_CHONK, "bugs", "it broke? tell us here"),
  { channel_type: "TextChannel", _id: CH.voice, server: DEN_CHONK, name: "campfire", voice: { max_users: 10 } } as unknown as API.Channel,
  text(CH.sketch, DEN_ART, "daily-frog"),
  text(CH.crit, DEN_ART, "feedback"),
  text(CH.lfg, DEN_GAME, "looking-for-group"),
  text(CH.clips, DEN_GAME, "clips"),
  {
    channel_type: "DirectMessage",
    _id: CH.dmPatty,
    active: true,
    recipients: [DEMO_ME, "01DEMO0000000000000000000A"],
  } as API.Channel,
];

type Seed = [channel: string, author: string, content: string, reactions?: Record<string, string[]>];

const seedMessages: Seed[] = [
  [CH.welcome, DEMO_ME, "welcome to **chonk HQ** 🎉 grab a role, say hi, post a frog."],
  [CH.welcome, "01DEMO0000000000000000000A", "hi!! the theme picker is unreal, I made a whole gameboy one already"],
  [CH.general, "01DEMO0000000000000000000B", "ok but why is the send button so satisfying to press"],
  [CH.general, "01DEMO0000000000000000000C", "it's the offset shadow. every button is a physical object now", { "🔥": ["01DEMO0000000000000000000B", DEMO_ME] }],
  [CH.general, DEMO_ME, "shipping animated avatars today. gif profile pics + gif banners, no paywall"],
  [CH.general, "01DEMO0000000000000000000A", "WAIT. no paywall??", { "😭": ["01DEMO0000000000000000000B"], "🐸": [DEMO_ME, "01DEMO0000000000000000000D"] }],
  [CH.general, "01DEMO0000000000000000000D", "hover my avatar 👀"],
  [CH.general, "01DEMO0000000000000000000E", "the *midnight cabinet* theme goes hard at 2am"],
  [CH.general, "01DEMO0000000000000000000B", "can we get a theme that's just... beige. for irony"],
  [CH.general, DEMO_ME, "no ❤️"],
  [CH.general, "01DEMO0000000000000000000C", "`npm run dev` and it just works. love that for us"],
  [CH.general, "01DEMO0000000000000000000A", "posting the frog in #showcase brb"],
  [CH.memes, "01DEMO0000000000000000000B", "https://chonk.chat is a real url now. we did it."],
  [CH.showcase, "01DEMO0000000000000000000A", "daily frog #41 🐸 — he's wearing a tiny hat", { "🎩": [DEMO_ME, "01DEMO0000000000000000000B", "01DEMO0000000000000000000E"] }],
  [CH.bugs, "01DEMO0000000000000000000C", "member list wobbles when you hover too fast. is this a bug or a feature"],
  [CH.bugs, DEMO_ME, "feature."],
  [CH.sketch, "01DEMO0000000000000000000A", "frog #42: astronaut"],
  [CH.lfg, "01DEMO0000000000000000000D", "anyone up for co-op tonight? 3 slots"],
  [CH.dmPatty, "01DEMO0000000000000000000A", "hey can you check my theme json? colors feel off"],
  [CH.dmPatty, DEMO_ME, "send it over, I'll poke at it"],
];

/** Hydrate the client with everything above. */
export function bootDemo(client: Client) {
  // users
  for (const u of users) {
    client.users.getOrCreate(u.id, {
      _id: u.id,
      username: u.username,
      discriminator: "0001",
      display_name: u.display,
      avatar: file("avatars", u.id.slice(-2).toLowerCase(), u.gif),
      status: u.status || u.presence ? { text: u.status, presence: u.presence } : undefined,
      relationship: u.id === DEMO_ME ? "User" : "Friend",
      online: !!u.online,
    });
  }
  client.user = client.users.get(DEMO_ME);

  // servers + members
  for (const s of servers) {
    client.servers.getOrCreate(s._id, s);
    for (const u of users) {
      client.serverMembers.getOrCreate(
        { server: s._id, user: u.id },
        {
          _id: { server: s._id, user: u.id },
          joined_at: new Date(Date.now() - 86400000 * 30).toISOString(),
          roles:
            s._id === DEN_CHONK
              ? u.id === DEMO_ME
                ? ["role-admin"]
                : u.username === "pixelpatty"
                  ? ["role-artist"]
                  : []
              : [],
        },
      );
    }
  }

  // channels
  for (const c of channels) client.channels.getOrCreate(c._id, c);

  // messages — spaced ~7 minutes apart ending now
  const start = Date.now() - seedMessages.length * 7 * 60_000;
  seedMessages.forEach(([channel, author, content, reactions], i) => {
    const id = ulid(start + i * 7 * 60_000);
    client.messages.getOrCreate(id, { _id: id, channel, author, content, reactions });
  });

  // Prevent any real network/ws use from listeners that check readiness.
  client.emit("ready");
}

/** Fake a "send" in demo mode so the composer works. */
export function demoSend(client: Client, channelId: string, content: string) {
  const id = ulid();
  const msg = client.messages.getOrCreate(id, { _id: id, channel: channelId, author: DEMO_ME, content }, true);
  client.emit("messageCreate", msg);
  // a little reply so the room feels alive
  if (/theme|gif|avatar|frog/i.test(content)) {
    setTimeout(() => {
      const rid = ulid();
      const replies = ["ooo yes", "🐸🐸🐸", "post it in #showcase!!", "this is why I'm here"];
      const r = client.messages.getOrCreate(
        rid,
        {
          _id: rid,
          channel: channelId,
          author: "01DEMO0000000000000000000A",
          content: replies[Math.floor(Math.random() * replies.length)],
          replies: [id],
        },
        true,
      );
      client.emit("messageCreate", r);
    }, 1400);
  }
}

/** Fake profile lookup for demo mode (real mode uses user.fetchProfile()). */
export function demoProfile(userId: string): { content?: string; bannerURL?: string; animatedBannerURL?: string } {
  const key = userId.slice(-2).toLowerCase();
  const bios: Record<string, string> = {
    me: "solo dev. building **chonk** in public. ask me about themes.",
    "0a": "I draw one frog every day. today's frog has a hat.",
    "0b": "professional snack haver",
    "0c": "ship it",
  };
  const hasBanner = key === "me" || key === "0a";
  return {
    content: bios[key],
    bannerURL: hasBanner ? `/demo-media/banners/${key}` : undefined,
    animatedBannerURL: hasBanner ? `/demo-media/banners/${key}/original` : undefined,
  };
}
