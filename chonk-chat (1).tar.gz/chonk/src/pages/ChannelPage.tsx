import { createMemo, Show } from "solid-js";
import { useParams } from "@solidjs/router";
import { client } from "../lib/client";
import ChannelSidebar from "../components/ChannelSidebar";
import DMSidebar from "../components/DMSidebar";
import ChatView from "../components/ChatView";
import MemberList from "../components/MemberList";
import { settings } from "../lib/settings";

/** /app/den/:server/:channel  and  /app/dm/:channel */
export default function ChannelPage() {
  const params = useParams();
  const server = createMemo(() => (params.server ? client.servers.get(params.server) : undefined));
  const channel = createMemo(() => {
    const id = params.channel || server()?.defaultChannel?.id;
    return id ? client.channels.get(id) : undefined;
  });

  return (
    <>
      <Show when={server()} fallback={<DMSidebar />}>
        {(s) => <ChannelSidebar server={s()} activeId={channel()?.id} />}
      </Show>
      <Show when={channel()} fallback={<EmptyChat />}>
        {(c) => <ChatView channel={c()} />}
      </Show>
      <Show when={server() && settings.showMembers}>
        <MemberList server={server()!} />
      </Show>
    </>
  );
}

function EmptyChat() {
  return (
    <div class="sticker grow" style={{ display: "grid", "place-items": "center" }}>
      <div class="muted">pick a room →</div>
    </div>
  );
}
