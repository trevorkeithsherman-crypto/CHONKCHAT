import { createEffect, createResource, createSignal, onCleanup, Show } from "solid-js";
import { brand } from "../brand";
import { login, register, appError, IS_DEMO, getApiUrl, setApiUrl, captchaKey } from "../lib/client";
import ThemeDots from "../components/ThemeDots";
import "./Login.css";

export default function Login() {
  const [mode, setMode] = createSignal<"login" | "register">("login");
  const [email, setEmail] = createSignal("");
  const [password, setPassword] = createSignal("");
  const [invite, setInvite] = createSignal("");
  const [busy, setBusy] = createSignal(false);
  const [msg, setMsg] = createSignal<string | null>(null);
  const [server, setServer] = createSignal(getApiUrl());
  const [siteKey] = createResource(captchaKey);
  const [captchaToken, setCaptchaToken] = createSignal<string | null>(null);
  let captchaEl: HTMLDivElement | undefined;
  let widgetId: string | null = null;

  // Render the hCaptcha widget when signing up on a server that requires it.
  createEffect(() => {
    const key = siteKey();
    if (mode() !== "register" || !key || !captchaEl) return;
    loadHCaptcha().then((hc) => {
      if (!captchaEl || widgetId) return;
      widgetId = hc.render(captchaEl, {
        sitekey: key,
        theme: document.documentElement.dataset.scheme === "dark" ? "dark" : "light",
        callback: (t: string) => setCaptchaToken(t),
        "expired-callback": () => setCaptchaToken(null),
      });
    });
  });
  createEffect(() => {
    if (mode() === "login" && widgetId) {
      widgetId = null;
      setCaptchaToken(null);
      if (captchaEl) captchaEl.innerHTML = "";
    }
  });
  onCleanup(() => (widgetId = null));

  const submit = async (e: Event) => {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      if (mode() === "login") {
        await login(email(), password());
      } else {
        if (siteKey() && !captchaToken()) throw new Error("please finish the captcha first");
        await register(email(), password(), invite(), captchaToken() ?? undefined);
        setMsg("Account created! Check your email to verify, then log in.");
        setMode("login");
      }
    } catch (err) {
      setMsg(err instanceof Error ? err.message : String(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div class="login wallpaper">
      <div class="login-card sticker pop-in">
        <div class="login-head">
          <div class="login-logo">
            <span class="login-blob" />
            <span class="display login-name">{brand.name}</span>
          </div>
          <p class="muted login-tagline">{brand.tagline}</p>
        </div>

        <form onSubmit={submit} class="col login-form">
          <label>
            <span class="label">email</span>
            <input
              class="input"
              type="email"
              required
              autocomplete="email"
              value={email()}
              onInput={(e) => setEmail(e.currentTarget.value)}
              placeholder="you@somewhere.chat"
            />
          </label>
          <label>
            <span class="label">password</span>
            <input
              class="input"
              type="password"
              required
              minLength={8}
              autocomplete={mode() === "login" ? "current-password" : "new-password"}
              value={password()}
              onInput={(e) => setPassword(e.currentTarget.value)}
              placeholder="••••••••"
            />
          </label>
          <Show when={mode() === "register"}>
            <label>
              <span class="label">invite code (if required)</span>
              <input class="input" value={invite()} onInput={(e) => setInvite(e.currentTarget.value)} />
            </label>
          </Show>

          <Show when={mode() === "register" && siteKey()}>
            <div class="login-captcha" ref={captchaEl} />
          </Show>

          <Show when={msg() || appError()}>
            <div class="login-msg sticker-sm">{msg() ?? appError()}</div>
          </Show>

          <button class="btn btn-accent login-submit" type="submit" disabled={busy()}>
            {busy() ? "hang on…" : mode() === "login" ? "let me in" : "make my account"}
          </button>
        </form>

        <div class="login-foot row">
          <button class="btn btn-ghost btn-sm" onClick={() => setMode(mode() === "login" ? "register" : "login")}>
            {mode() === "login" ? "new here? sign up" : "have an account? log in"}
          </button>
          <span class="grow" />
          <a class="btn btn-sm btn-accent2" href="/?demo=1">
            try the demo
          </a>
        </div>
        <Show when={IS_DEMO}>
          <p class="muted login-demo-note">demo mode is on — you'll be dropped in as a fake user.</p>
        </Show>

        <details class="login-server">
          <summary class="muted">server: <span class="mono">{getApiUrl()}</span></summary>
          <div class="row" style={{ "margin-top": "8px" }}>
            <input class="input" value={server()} onInput={(e) => setServer(e.currentTarget.value)} placeholder="https://your.domain/api" />
            <button class="btn btn-sm" onClick={() => setApiUrl(server())}>
              use
            </button>
          </div>
          <p class="muted" style={{ "font-size": "11px", margin: "6px 0 0" }}>
            any Stoat-compatible API works — self-hosted or the public one.
          </p>
        </details>
      </div>

      <div class="login-themes pop-in">
        <span class="label">pick a vibe</span>
        <ThemeDots />
      </div>
    </div>
  );
}

type HCaptcha = {
  render: (el: HTMLElement, opts: Record<string, unknown>) => string;
};
let hcPromise: Promise<HCaptcha> | undefined;
function loadHCaptcha(): Promise<HCaptcha> {
  const w = window as unknown as { hcaptcha?: HCaptcha };
  if (w.hcaptcha) return Promise.resolve(w.hcaptcha);
  if (!hcPromise) {
    hcPromise = new Promise((resolve, reject) => {
      const s = document.createElement("script");
      s.src = "https://js.hcaptcha.com/1/api.js?render=explicit";
      s.async = true;
      s.onload = () => (w.hcaptcha ? resolve(w.hcaptcha) : reject(new Error("hcaptcha failed to load")));
      s.onerror = () => reject(new Error("hcaptcha failed to load"));
      document.head.appendChild(s);
    });
  }
  return hcPromise;
}
