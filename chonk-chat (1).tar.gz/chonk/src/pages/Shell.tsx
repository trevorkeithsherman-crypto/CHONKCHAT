import { createSignal, type ParentProps } from "solid-js";
import ServerRail from "../components/ServerRail";
import SettingsModal from "../components/SettingsModal";
import { UIProvider } from "../lib/ui";
import "./Shell.css";

/** App frame: rail | (sidebar + chat + members, provided by child routes) */
export default function Shell(props: ParentProps) {
  const [settingsOpen, setSettingsOpen] = createSignal(false);
  return (
    <UIProvider value={{ openSettings: () => setSettingsOpen(true) }}>
      <div class="shell wallpaper">
        <ServerRail />
        <div class="shell-main">{props.children}</div>
        <SettingsModal open={settingsOpen()} onClose={() => setSettingsOpen(false)} />
      </div>
    </UIProvider>
  );
}
