import { createMemo, For, Show } from "solid-js";
import { A } from "@solidjs/router";
import { client } from "../lib/client";
import { brand } from "../brand";
import DMSidebar from "../components/DMSidebar";
import Avatar from "../components/Avatar";
import "./Home.css";

/** /app — DM sidebar + a friendly landing panel */
export default function Home() {
  const friends = createMemo(() => client.users.filter((u) => u.relationship === "Friend"));
  const online = createMemo(() => friends().filter((u) => u.online));

  return (
    <>
      <DMSidebar />
      <div class="home sticker grow">
        <div class="home-hero">
          <div class="display home-title">hey {client.user?.displayName ?? "you"} 👋</div>
          <p class="muted">
            {online().length} of your {friends().length} friends are around. go bother them.
          </p>
        </div>

        <div class="home-grid">
          <section class="home-card sticker-sm">
            <span class="label">online now</span>
            <div class="col" style={{ gap: "6px" }}>
              <For each={online()} fallback={<span class="muted">nobody yet — it's quiet</span>}>
                {(u) => (
                  <button
                    class="home-friend row"
                    onClick={async () => {
                      const dm = await u.openDM().catch(() => undefined);
                      if (dm) location.assign(`/app/dm/${dm.id}`);
                    }}
                  >
                    <Avatar src={u.avatarURL} animatedSrc={u.animatedAvatarURL} size={34} presence={u.presence} fallback={u.displayName.slice(0, 1)} />
                    <div class="col grow" style={{ "align-items": "flex-start" }}>
                      <span class="display">{u.displayName}</span>
                      <Show when={u.status?.text}>
                        <span class="muted truncate" style={{ "font-size": "12px" }}>
                          {u.status?.text}
                        </span>
                      </Show>
                    </div>
                  </button>
                )}
              </For>
            </div>
          </section>

          <section class="home-card sticker-sm">
            <span class="label">your {brand.serverWordPlural}</span>
            <div class="col" style={{ gap: "6px" }}>
              <For each={client.servers.toList()}>
                {(s) => (
                  <A class="home-friend row" href={`/app/den/${s.id}/${s.defaultChannel?.id ?? ""}`}>
                    <Avatar src={s.iconURL} animatedSrc={s.animatedIconURL} size={34} shape="squircle" fallback={s.name.slice(0, 2)} />
                    <span class="display">{s.name}</span>
                    <Show when={s.unread}>
                      <span class="pill pill-accent" style={{ "margin-left": "auto" }}>
                        new
                      </span>
                    </Show>
                  </A>
                )}
              </For>
            </div>
          </section>
        </div>
      </div>
    </>
  );
}
