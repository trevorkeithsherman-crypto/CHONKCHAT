import { createEffect, createMemo, createSignal, For, on, onMount, Show } from "solid-js";
import type { Channel, Message } from "stoat.js";
import { client, IS_DEMO } from "../lib/client";
import { demoSend } from "../lib/demo";
import { settings, setSetting } from "../lib/settings";
import MessageItem from "./MessageItem";
import Composer from "./Composer";
import "./ChatView.css";

const GROUP_WINDOW = 5 * 60_000;

/** The main chat column: header, message list, composer. */
export default function ChatView(props: { channel: Channel }) {
  let scroller!: HTMLDivElement;
  const [loading, setLoading] = createSignal(false);

  const messages = createMemo(() =>
    client.messages
      .filter((m) => m.channelId === props.channel.id)
      .sort((a, b) => (a.id < b.id ? -1 : a.id > b.id ? 1 : 0)),
  );

  /** group consecutive messages by the same author within 5 minutes */
  const grouped = createMemo(() => {
    const out: { head: Message; tail: Message[] }[] = [];
    for (const m of messages()) {
      const last = out[out.length - 1];
      const prev = last ? (last.tail[last.tail.length - 1] ?? last.head) : undefined;
      if (
        prev &&
        prev.authorId === m.authorId &&
        !m.replyIds?.length &&
        m.createdAt.getTime() - prev.createdAt.getTime() < GROUP_WINDOW
      ) {
        last.tail.push(m);
      } else {
        out.push({ head: m, tail: [] });
      }
    }
    return out;
  });

  const scrollToBottom = () => {
    requestAnimationFrame(() => {
      scroller?.scrollTo({ top: scroller.scrollHeight });
    });
  };

  // Load history when channel changes (real backend only — demo is pre-hydrated).
  createEffect(
    on(
      () => props.channel.id,
      async () => {
        if (!IS_DEMO) {
          setLoading(true);
          try {
            await props.channel.fetchMessagesWithUsers({ limit: 60 });
            props.channel.ack().catch(() => {});
          } catch (e) {
            console.error(e);
          } finally {
            setLoading(false);
          }
        }
        scrollToBottom();
      },
    ),
  );

  // Stick to bottom on new messages.
  createEffect(on(() => messages().length, scrollToBottom, { defer: true }));
  onMount(scrollToBottom);

  const send = async (text: string) => {
    if (IS_DEMO) {
      demoSend(client, props.channel.id, text);
      return;
    }
    await props.channel.sendMessage(text);
  };

  const typing = createMemo(() => props.channel.typing.filter((u) => !u.self));

  return (
    <section class="chat sticker grow">
      <header class="chat-head">
        <span class="chat-glyph mono">{props.channel.isVoice ? "♪" : props.channel.type === "DirectMessage" ? "@" : "#"}</span>
        <div class="col grow" style={{ "min-width": 0 }}>
          <div class="display chat-title truncate">{props.channel.displayName ?? props.channel.name}</div>
          <Show when={props.channel.description}>
            <div class="muted chat-desc truncate">{props.channel.description}</div>
          </Show>
        </div>
        <Show when={props.channel.server}>
          <button
            class="btn btn-ghost btn-sm"
            onClick={() => setSetting("showMembers", !settings.showMembers)}
          >
            {settings.showMembers ? "hide members" : "members"}
          </button>
        </Show>
      </header>

      <div class="chat-scroll" ref={scroller} classList={{ compact: settings.density === "compact" }}>
        <div class="chat-intro">
          <div class="chat-intro-glyph display">{props.channel.isVoice ? "♪" : "#"}</div>
          <div class="display chat-intro-title">
            welcome to {props.channel.type === "DirectMessage" ? "" : "#"}
            {props.channel.displayName ?? props.channel.name}
          </div>
          <div class="muted">{props.channel.description ?? "this is the very beginning. say something nice."}</div>
        </div>

        <Show when={loading()}>
          <div class="muted" style={{ padding: "12px 20px" }}>
            loading…
          </div>
        </Show>

        <For each={grouped()}>
          {(g) => (
            <div class="msg-group">
              <MessageItem message={g.head} head />
              <For each={g.tail}>{(m) => <MessageItem message={m} />}</For>
            </div>
          )}
        </For>
      </div>

      <div class="chat-typing muted" classList={{ visible: typing().length > 0 }}>
        <span class="typing-dots">
          <i />
          <i />
          <i />
        </span>
        {typing()
          .map((u) => u.displayName)
          .join(", ")}{" "}
        {typing().length === 1 ? "is" : "are"} typing
      </div>

      <Composer channel={props.channel} onSend={send} />
    </section>
  );
}
