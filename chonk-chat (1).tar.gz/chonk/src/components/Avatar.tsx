import { createMemo, createSignal, Show, type JSX } from "solid-js";
import { settings } from "../lib/settings";
import "./Avatar.css";

export type AvatarProps = {
  /** static image url */
  src?: string;
  /** animated (gif/webp) url — shown on hover / always per settings */
  animatedSrc?: string;
  /** fallback initials/emoji */
  fallback?: string;
  size?: number;
  /** presence dot */
  presence?: "Online" | "Idle" | "Focus" | "Busy" | "Invisible" | "Offline";
  /** square-ish sticker (servers) vs round (users) */
  shape?: "round" | "squircle";
  class?: string;
  style?: JSX.CSSProperties;
  /** when true, a parent .gif-group's hover triggers the animation */
  groupHover?: boolean;
};

/**
 * Avatar with first-class animated GIF support. Static frame by default,
 * swaps to the animated original on hover (or always, per user setting).
 */
export default function Avatar(props: AvatarProps) {
  const [hover, setHover] = createSignal(false);
  const size = () => props.size ?? 40;

  const isAnimated = () => !!props.animatedSrc && props.animatedSrc !== props.src;
  const showAnimated = createMemo(() => {
    if (!isAnimated()) return false;
    if (settings.animate === "always") return true;
    if (settings.animate === "never") return false;
    return hover();
  });

  const src = () => (showAnimated() ? props.animatedSrc : props.src);

  return (
    <span
      class={`avatar ${props.shape ?? "round"} ${props.groupHover ? "group-hover" : ""} ${props.class ?? ""}`}
      style={{ "--size": `${size()}px`, ...props.style }}
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      data-animated={isAnimated() ? "1" : undefined}
    >
      <Show when={src()} fallback={<span class="avatar-fallback display">{props.fallback ?? "?"}</span>}>
        <img src={src()} alt="" loading="lazy" draggable={false} />
      </Show>
      <Show when={isAnimated() && settings.animate === "hover" && !hover()}>
        <span class="avatar-gif-badge mono" title="animated — hover to play">GIF</span>
      </Show>
      <Show when={props.presence}>
        <span class={`presence presence-${props.presence?.toLowerCase()}`} />
      </Show>
    </span>
  );
}
