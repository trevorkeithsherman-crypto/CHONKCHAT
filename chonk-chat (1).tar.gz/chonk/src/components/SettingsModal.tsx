import { createSignal, For, Show } from "solid-js";
import { useTheme } from "../theme/ThemeProvider";
import type { ThemeTokens } from "../theme/themes";
import { settings, setSetting, type Settings } from "../lib/settings";
import { client, IS_DEMO } from "../lib/client";
import { brand } from "../brand";
import Avatar from "./Avatar";
import "./SettingsModal.css";

type Tab = "themes" | "editor" | "profile" | "app";

const COLOR_FIELDS: { key: keyof ThemeTokens; label: string }[] = [
  { key: "bg", label: "background" },
  { key: "surface", label: "panels" },
  { key: "surface2", label: "raised" },
  { key: "ink", label: "text" },
  { key: "inkMuted", label: "muted text" },
  { key: "line", label: "outline" },
  { key: "accent", label: "accent" },
  { key: "accent2", label: "accent 2" },
  { key: "accent3", label: "accent 3" },
  { key: "onAccent", label: "text on accent" },
];

export default function SettingsModal(props: { open: boolean; onClose: () => void }) {
  const [tab, setTab] = createSignal<Tab>("themes");
  const theme = useTheme();
  const [importText, setImportText] = createSignal("");
  const [note, setNote] = createSignal<string | null>(null);

  const t = () => theme.active().tokens;

  const flash = (s: string) => {
    setNote(s);
    setTimeout(() => setNote(null), 1800);
  };

  return (
    <Show when={props.open}>
      <div class="modal-backdrop" onClick={props.onClose} />
      <div class="modal sticker pop-in" role="dialog" aria-label="settings">
        <nav class="modal-nav">
          <div class="display modal-brand">{brand.name}</div>
          <For each={[
            ["themes", "🎨 themes"],
            ["editor", "🛠️ theme editor"],
            ["profile", "🙂 profile"],
            ["app", "⚙️ app"],
          ] as [Tab, string][]}>
            {([id, label]) => (
              <button class="modal-tab" classList={{ active: tab() === id }} onClick={() => setTab(id)}>
                {label}
              </button>
            )}
          </For>
          <span class="grow" />
          <Show when={IS_DEMO}>
            <span class="pill pill-accent3">demo</span>
          </Show>
        </nav>

        <div class="modal-body">
          <button class="btn btn-icon modal-close" onClick={props.onClose} title="close">
            ✕
          </button>

          {/* ---------- THEMES ---------- */}
          <Show when={tab() === "themes"}>
            <h2 class="display">themes</h2>
            <p class="muted">tap one. everything re-skins instantly. remix any of them in the editor.</p>
            <div class="theme-grid">
              <For each={theme.all()}>
                {(th) => (
                  <button
                    class="theme-card sticker-sm"
                    classList={{ active: theme.active().id === th.id }}
                    onClick={() => theme.setActive(th.id)}
                    style={{ background: th.tokens.bg, color: th.tokens.ink, "border-color": th.tokens.line }}
                  >
                    <div class="theme-card-preview" style={{ background: th.tokens.surface, "border-color": th.tokens.line }}>
                      <span style={{ background: th.tokens.accent }} />
                      <span style={{ background: th.tokens.accent2 }} />
                      <span style={{ background: th.tokens.accent3 }} />
                    </div>
                    <div class="theme-card-name" style={{ "font-family": th.tokens.fontDisplay }}>
                      {th.emoji} {th.name}
                    </div>
                    <div class="theme-card-desc" style={{ color: th.tokens.inkMuted }}>
                      {th.description}
                    </div>
                    <Show when={!th.builtin}>
                      <span
                        class="theme-card-remove"
                        onClick={(e) => {
                          e.stopPropagation();
                          theme.remove(th.id);
                        }}
                      >
                        remove
                      </span>
                    </Show>
                  </button>
                )}
              </For>
            </div>
          </Show>

          {/* ---------- EDITOR ---------- */}
          <Show when={tab() === "editor"}>
            <h2 class="display">theme editor</h2>
            <p class="muted">
              editing <strong>{theme.active().name}</strong>
              {theme.active().builtin ? " — your first change forks it into a custom theme." : "."}
            </p>

            <div class="editor-grid">
              <For each={COLOR_FIELDS}>
                {(f) => (
                  <label class="editor-color sticker-sm">
                    <input type="color" value={String(t()[f.key])} onInput={(e) => theme.patch({ [f.key]: e.currentTarget.value })} />
                    <span class="label" style={{ margin: 0 }}>
                      {f.label}
                    </span>
                    <span class="mono editor-hex">{String(t()[f.key])}</span>
                  </label>
                )}
              </For>
            </div>

            <div class="editor-sliders">
              <Slider label="corner radius" min={0} max={32} value={t().radius} onChange={(v) => theme.patch({ radius: v })} unit="px" />
              <Slider label="outline width" min={0} max={5} value={t().lineWidth} onChange={(v) => theme.patch({ lineWidth: v })} unit="px" />
              <Slider label="sticker shadow" min={0} max={10} value={t().shadow} onChange={(v) => theme.patch({ shadow: v })} unit="px" />
              <Slider label="motion" min={0} max={2} step={0.25} value={t().motion} onChange={(v) => theme.patch({ motion: v })} unit="×" />
              <Slider
                label="pattern overlay"
                min={0}
                max={0.3}
                step={0.01}
                value={t().patternOpacity ?? 0}
                onChange={(v) => theme.patch({ patternOpacity: v })}
              />
            </div>

            <div class="editor-row">
              <label class="grow">
                <span class="label">display font</span>
                <select class="input" value={t().fontDisplay} onChange={(e) => theme.patch({ fontDisplay: e.currentTarget.value })}>
                  <option value={`"Fredoka", "Nunito", system-ui, sans-serif`}>Fredoka (rounded)</option>
                  <option value={`"Space Mono", ui-monospace, monospace`}>Space Mono (retro)</option>
                  <option value={`"Nunito", system-ui, sans-serif`}>Nunito (soft)</option>
                  <option value={`system-ui, sans-serif`}>System</option>
                </select>
              </label>
              <label class="grow">
                <span class="label">scheme</span>
                <select class="input" value={t().scheme} onChange={(e) => theme.patch({ scheme: e.currentTarget.value as "light" | "dark" })}>
                  <option value="light">light</option>
                  <option value="dark">dark</option>
                </select>
              </label>
            </div>

            <label>
              <span class="label">wallpaper (css background or image url — gifs welcome)</span>
              <input
                class="input"
                value={t().wallpaper ?? ""}
                placeholder="url(https://…/loop.gif) center / cover"
                onChange={(e) => theme.patch({ wallpaper: e.currentTarget.value || "none" })}
              />
            </label>

            <div class="editor-actions row">
              <button class="btn btn-sm" onClick={() => theme.fork()}>
                duplicate
              </button>
              <button
                class="btn btn-sm btn-accent2"
                onClick={() => {
                  navigator.clipboard?.writeText(theme.exportJSON());
                  flash("copied theme json ✓");
                }}
              >
                export json
              </button>
              <span class="grow" />
              <Show when={note()}>
                <span class="pill pill-accent3">{note()}</span>
              </Show>
            </div>

            <details class="editor-import">
              <summary class="muted">import a theme from json</summary>
              <textarea class="input mono" rows={4} value={importText()} onInput={(e) => setImportText(e.currentTarget.value)} />
              <button
                class="btn btn-sm"
                style={{ "margin-top": "8px" }}
                onClick={() => {
                  const r = theme.importJSON(importText());
                  flash(r ? `imported ${r.name} ✓` : "that json didn't look like a theme");
                  if (r) setImportText("");
                }}
              >
                import
              </button>
            </details>
          </Show>

          {/* ---------- PROFILE ---------- */}
          <Show when={tab() === "profile"}>
            <h2 class="display">profile</h2>
            <p class="muted">animated gif avatars and banners are free here. no nitro. no tiers.</p>
            <div class="row" style={{ gap: "16px", "align-items": "flex-start" }}>
              <Avatar src={client.user?.avatarURL} animatedSrc={client.user?.animatedAvatarURL} size={96} fallback="?" />
              <div class="col grow" style={{ gap: "10px" }}>
                <div class="display" style={{ "font-size": "20px" }}>
                  {client.user?.displayName}
                </div>
                <div class="muted mono">@{client.user?.username}</div>
                <div class="row">
                  <UploadButton label="new avatar" tag="avatars" onDone={() => flash("avatar updated ✓")} />
                  <UploadButton label="new banner" tag="backgrounds" onDone={() => flash("banner updated ✓")} />
                </div>
                <Show when={note()}>
                  <span class="pill pill-accent3">{note()}</span>
                </Show>
              </div>
            </div>
          </Show>

          {/* ---------- APP ---------- */}
          <Show when={tab() === "app"}>
            <h2 class="display">app</h2>
            <Choice<Settings["animate"]>
              label="play animated avatars & banners"
              value={settings.animate}
              options={[
                ["always", "always"],
                ["hover", "on hover"],
                ["never", "never"],
              ]}
              onChange={(v) => setSetting("animate", v)}
            />
            <Choice<Settings["density"]>
              label="message density"
              value={settings.density}
              options={[
                ["cozy", "cozy"],
                ["compact", "compact"],
              ]}
              onChange={(v) => setSetting("density", v)}
            />
            <Choice<"on" | "off">
              label="send sound"
              value={settings.sounds ? "on" : "off"}
              options={[
                ["on", "pop"],
                ["off", "silent"],
              ]}
              onChange={(v) => setSetting("sounds", v === "on")}
            />
          </Show>
        </div>
      </div>
    </Show>
  );
}

function Slider(props: { label: string; min: number; max: number; step?: number; value: number; unit?: string; onChange: (v: number) => void }) {
  return (
    <label class="slider">
      <span class="label" style={{ margin: 0 }}>
        {props.label}
      </span>
      <input
        type="range"
        min={props.min}
        max={props.max}
        step={props.step ?? 1}
        value={props.value}
        onInput={(e) => props.onChange(Number(e.currentTarget.value))}
      />
      <span class="mono slider-val">
        {props.value}
        {props.unit ?? ""}
      </span>
    </label>
  );
}

function Choice<T extends string>(props: { label: string; value: T; options: [T, string][]; onChange: (v: T) => void }) {
  return (
    <div class="choice">
      <span class="label">{props.label}</span>
      <div class="row">
        <For each={props.options}>
          {([v, l]) => (
            <button class="btn btn-sm" classList={{ "btn-accent": props.value === v }} onClick={() => props.onChange(v)}>
              {l}
            </button>
          )}
        </For>
      </div>
    </div>
  );
}

/** Uploads an image (gif/png/webp) to the media server and applies it to the profile. */
function UploadButton(props: { label: string; tag: "avatars" | "backgrounds"; onDone: () => void }) {
  let input!: HTMLInputElement;
  const [busy, setBusy] = createSignal(false);
  const pick = async () => {
    const f = input.files?.[0];
    if (!f) return;
    if (IS_DEMO) {
      props.onDone();
      return;
    }
    setBusy(true);
    try {
      const id = await client.uploadFile(props.tag, f);
      if (props.tag === "avatars") await client.user?.edit({ avatar: id });
      else await client.user?.edit({ profile: { background: id } });
      props.onDone();
    } catch (e) {
      console.error(e);
      alert("upload failed — check the file size limit on your server");
    } finally {
      setBusy(false);
      input.value = "";
    }
  };
  return (
    <>
      <input ref={input} type="file" accept="image/gif,image/png,image/jpeg,image/webp" class="sr-only" onChange={pick} />
      <button class="btn btn-sm btn-accent" disabled={busy()} onClick={() => input.click()}>
        {busy() ? "uploading…" : props.label}
      </button>
    </>
  );
}
