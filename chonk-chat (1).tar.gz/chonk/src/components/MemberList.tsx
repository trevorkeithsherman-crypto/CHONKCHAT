import { createMemo, createSignal, For, Show } from "solid-js";
import type { Server, ServerMember } from "stoat.js";
import { client } from "../lib/client";
import Avatar from "./Avatar";
import ProfileCard from "./ProfileCard";
import "./MemberList.css";

/** Right column: members grouped by hoisted role / online / offline. */
export default function MemberList(props: { server: Server }) {
  const [open, setOpen] = createSignal<ServerMember | null>(null);

  const members = createMemo(() => client.serverMembers.filter((m) => m.id.server === props.server.id));

  const groups = createMemo(() => {
    const online: ServerMember[] = [];
    const offline: ServerMember[] = [];
    for (const m of members()) (m.user?.online ? online : offline).push(m);
    const byName = (a: ServerMember, b: ServerMember) =>
      (a.nickname ?? a.user?.displayName ?? "").localeCompare(b.nickname ?? b.user?.displayName ?? "");
    return [
      { title: "online", list: online.sort(byName) },
      { title: "offline", list: offline.sort(byName) },
    ].filter((g) => g.list.length);
  });

  return (
    <aside class="members sticker">
      <div class="members-head">
        <span class="display">members</span>
        <span class="pill">{members().length}</span>
      </div>
      <div class="members-scroll">
        <For each={groups()}>
          {(g) => (
            <div class="members-group">
              <div class="label">
                {g.title} — {g.list.length}
              </div>
              <For each={g.list}>
                {(m) => {
                  const u = () => m.user;
                  const role = () => m.hoistedRole ?? m.orderedRoles[0];
                  return (
                    <button class="member row" classList={{ offline: !u()?.online }} onClick={() => setOpen(m)}>
                      <Avatar
                        src={m.avatarURL ?? u()?.avatarURL}
                        animatedSrc={m.animatedAvatarURL ?? u()?.animatedAvatarURL}
                        fallback={(m.nickname ?? u()?.displayName ?? "?").slice(0, 1)}
                        size={32}
                        presence={u()?.presence}
                      />
                      <span class="col grow" style={{ "min-width": 0, "align-items": "flex-start" }}>
                        <span class="truncate member-name" style={{ color: role()?.colour ?? undefined }}>
                          {m.nickname ?? u()?.displayName}
                        </span>
                        <Show when={u()?.status?.text}>
                          <span class="muted truncate member-status">{u()?.status?.text}</span>
                        </Show>
                      </span>
                    </button>
                  );
                }}
              </For>
            </div>
          )}
        </For>
      </div>
      <Show when={open()}>{(m) => <ProfileCard member={m()} onClose={() => setOpen(null)} />}</Show>
    </aside>
  );
}
