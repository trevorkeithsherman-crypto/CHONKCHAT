import { Show } from "solid-js";
import { client, logout } from "../lib/client";
import { useUI } from "../lib/ui";
import Avatar from "./Avatar";
import "./UserPanel.css";

/** Bottom-of-sidebar "you" card. */
export default function UserPanel() {
  const ui = useUI();
  const me = () => client.user;
  return (
    <Show when={me()}>
      {(u) => (
        <div class="userpanel">
          <Avatar
            src={u().avatarURL}
            animatedSrc={u().animatedAvatarURL}
            fallback={u().displayName.slice(0, 1)}
            size={38}
            presence={u().presence}
          />
          <div class="col grow" style={{ "min-width": 0 }}>
            <span class="display truncate userpanel-name">{u().displayName}</span>
            <span class="muted truncate userpanel-status">{u().status?.text ?? `@${u().username}`}</span>
          </div>
          <button class="btn btn-icon btn-ghost" title="settings & themes" onClick={ui.openSettings}>
            ✦
          </button>
          <button class="btn btn-icon btn-ghost" title="log out" onClick={logout}>
            ⏻
          </button>
        </div>
      )}
    </Show>
  );
}
