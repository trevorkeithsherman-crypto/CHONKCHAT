import { createMemo, For, Show } from "solid-js";
import { A, useParams } from "@solidjs/router";
import { client } from "../lib/client";
import Avatar from "./Avatar";
import UserPanel from "./UserPanel";
import "./Sidebar.css";

/** Home sidebar: direct messages + groups. */
export default function DMSidebar() {
  const params = useParams();
  const dms = createMemo(() =>
    client.channels
      .filter((c) => (c.type === "DirectMessage" && c.active) || c.type === "Group")
      .sort((a, b) => (b.lastMessageAt?.getTime() ?? 0) - (a.lastMessageAt?.getTime() ?? 0)),
  );

  return (
    <aside class="sidebar sticker">
      <header class="sidebar-head">
        <div class="sidebar-title display">messages</div>
        <div class="sidebar-desc muted">friends, groups, and the occasional frog</div>
      </header>
      <div class="sidebar-scroll">
        <For each={dms()} fallback={<div class="muted" style={{ padding: "12px" }}>no chats yet</div>}>
          {(c) => {
            const u = () => c.recipient;
            return (
              <A href={`/app/dm/${c.id}`} class="room dm" classList={{ active: c.id === params.channel, unread: c.unread }}>
                <Avatar
                  src={c.type === "Group" ? c.iconURL : u()?.avatarURL}
                  animatedSrc={c.type === "Group" ? c.animatedIconURL : u()?.animatedAvatarURL}
                  fallback={(c.displayName ?? "?").slice(0, 1)}
                  size={30}
                  presence={c.type === "DirectMessage" ? u()?.presence : undefined}
                />
                <span class="col grow" style={{ "min-width": 0 }}>
                  <span class="truncate">{c.displayName}</span>
                  <Show when={c.lastMessage?.content}>
                    <span class="muted truncate" style={{ "font-size": "11px" }}>
                      {c.lastMessage?.content}
                    </span>
                  </Show>
                </span>
              </A>
            );
          }}
        </For>
      </div>
      <UserPanel />
    </aside>
  );
}
