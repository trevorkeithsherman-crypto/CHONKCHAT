import { For, Show } from "solid-js";
import { A } from "@solidjs/router";
import type { Server } from "stoat.js";
import UserPanel from "./UserPanel";
import { settings } from "../lib/settings";
import "./Sidebar.css";

/** Den (server) sidebar: banner, name, categorised rooms, and your user panel. */
export default function ChannelSidebar(props: { server: Server; activeId?: string }) {
  const bannerSrc = () =>
    settings.animate === "always" ? (props.server.banner?.createFileURL(true) ?? props.server.bannerURL) : props.server.bannerURL;

  return (
    <aside class="sidebar sticker">
      <header class="sidebar-head" classList={{ "has-banner": !!props.server.bannerURL }}>
        <Show when={props.server.bannerURL}>
          <img class="sidebar-banner" src={bannerSrc()} alt="" />
        </Show>
        <div class="sidebar-title display truncate">{props.server.name}</div>
        <Show when={props.server.description}>
          <div class="sidebar-desc muted truncate">{props.server.description}</div>
        </Show>
      </header>

      <div class="sidebar-scroll">
        <For each={props.server.orderedChannels}>
          {(cat) => (
            <div class="sidebar-cat">
              <Show when={cat.id !== "default"}>
                <div class="sidebar-cat-title label">{cat.title}</div>
              </Show>
              <For each={cat.channels}>
                {(ch) => (
                  <A
                    href={`/app/den/${props.server.id}/${ch.id}`}
                    class="room"
                    classList={{ active: ch.id === props.activeId, unread: ch.unread && ch.id !== props.activeId }}
                  >
                    <span class="room-glyph mono">{ch.isVoice ? "♪" : "#"}</span>
                    <span class="truncate grow">{ch.name}</span>
                    <Show when={(ch.mentions?.size ?? 0) > 0}>
                      <span class="room-mentions">{ch.mentions?.size}</span>
                    </Show>
                  </A>
                )}
              </For>
            </div>
          )}
        </For>
      </div>

      <UserPanel />
    </aside>
  );
}
