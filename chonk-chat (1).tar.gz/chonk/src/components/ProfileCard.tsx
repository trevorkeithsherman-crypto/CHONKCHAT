import { createResource, createSignal, For, Show } from "solid-js";
import type { ServerMember } from "stoat.js";
import { IS_DEMO } from "../lib/client";
import { demoProfile } from "../lib/demo";
import { settings } from "../lib/settings";
import { Markdown } from "../lib/markdown";
import Avatar from "./Avatar";
import "./ProfileCard.css";

type Profile = { content?: string; bannerURL?: string; animatedBannerURL?: string };

/** Popover profile: animated banner, big avatar, roles, bio. */
export default function ProfileCard(props: { member: ServerMember; onClose: () => void }) {
  const u = () => props.member.user;
  const [hover, setHover] = createSignal(false);

  const [profile] = createResource<Profile>(async () => {
    if (IS_DEMO) return demoProfile(props.member.id.user);
    const p = await u()?.fetchProfile();
    return p ? { content: p.content, bannerURL: p.bannerURL, animatedBannerURL: p.animatedBannerURL } : {};
  });

  const banner = () => {
    const p = profile();
    if (!p?.bannerURL) return undefined;
    const animate = settings.animate === "always" || (settings.animate === "hover" && hover());
    return animate ? (p.animatedBannerURL ?? p.bannerURL) : p.bannerURL;
  };

  return (
    <>
      <div class="profile-backdrop" onClick={props.onClose} />
      <div class="profile sticker pop-in" onMouseEnter={() => setHover(true)} onMouseLeave={() => setHover(false)}>
        <div class="profile-banner" style={{ background: banner() ? undefined : "var(--accent)" }}>
          <Show when={banner()}>
            <img src={banner()} alt="" />
          </Show>
          <Show when={profile()?.animatedBannerURL && settings.animate === "hover"}>
            <span class="profile-gif mono">GIF</span>
          </Show>
        </div>
        <div class="profile-avatar">
          <Avatar
            src={props.member.avatarURL ?? u()?.avatarURL}
            animatedSrc={props.member.animatedAvatarURL ?? u()?.animatedAvatarURL}
            fallback={(u()?.displayName ?? "?").slice(0, 1)}
            size={84}
            presence={u()?.presence}
          />
        </div>
        <div class="profile-body">
          <div class="display profile-name">{props.member.nickname ?? u()?.displayName}</div>
          <div class="muted mono profile-handle">
            @{u()?.username}#{u()?.discriminator}
          </div>
          <Show when={u()?.status?.text}>
            <div class="profile-status sticker-sm">{u()?.status?.text}</div>
          </Show>
          <Show when={props.member.orderedRoles.length}>
            <div class="profile-roles">
              <For each={props.member.orderedRoles}>
                {(r) => (
                  <span class="pill" style={{ background: r.colour ?? undefined }}>
                    {r.name}
                  </span>
                )}
              </For>
            </div>
          </Show>
          <Show when={profile()?.content}>
            <div class="profile-bio">
              <span class="label">about</span>
              <Markdown text={profile()!.content!} />
            </div>
          </Show>
          <div class="row" style={{ "margin-top": "14px" }}>
            <button
              class="btn btn-accent btn-sm grow"
              onClick={async () => {
                if (IS_DEMO) return props.onClose();
                const dm = await u()?.openDM();
                if (dm) location.assign(`/app/dm/${dm.id}`);
              }}
            >
              message
            </button>
            <button class="btn btn-sm" onClick={props.onClose}>
              close
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
