import { For } from "solid-js";
import { useTheme } from "../theme/ThemeProvider";
import "./ThemeDots.css";

/** Row of little theme swatches — click to switch instantly. */
export default function ThemeDots() {
  const theme = useTheme();
  return (
    <div class="theme-dots row">
      <For each={theme.all()}>
        {(t) => (
          <button
            class={`theme-dot ${theme.active().id === t.id ? "active" : ""}`}
            title={t.name}
            onClick={() => theme.setActive(t.id)}
            style={{
              background: `linear-gradient(135deg, ${t.tokens.bg} 0 40%, ${t.tokens.accent} 40% 70%, ${t.tokens.accent2} 70%)`,
              "border-color": t.tokens.line,
            }}
          >
            <span class="theme-dot-emoji">{t.emoji}</span>
          </button>
        )}
      </For>
    </div>
  );
}
