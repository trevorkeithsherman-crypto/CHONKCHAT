import { createMemo, For, Show } from "solid-js";
import type { Message } from "stoat.js";
import { client, IS_DEMO } from "../lib/client";
import { Markdown } from "../lib/markdown";
import Avatar from "./Avatar";
import "./MessageItem.css";

const QUICK = ["👍", "🔥", "😂", "🐸", "❤️"];

function fmtTime(d: Date) {
  return d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
}
function fmtDate(d: Date) {
  const today = new Date();
  const same = d.toDateString() === today.toDateString();
  return same ? `today at ${fmtTime(d)}` : d.toLocaleDateString([], { month: "short", day: "numeric" }) + " " + fmtTime(d);
}

/** One message row. `head` = first in its author group (shows avatar + name). */
export default function MessageItem(props: { message: Message; head?: boolean }) {
  const m = () => props.message;
  const author = () => m().author;
  const name = () => m().username ?? author()?.displayName ?? "unknown";
  const colour = () => m().roleColour ?? undefined;
  const replyTo = createMemo(() => {
    const id = m().replyIds?.[0];
    return id ? client.messages.get(id) : undefined;
  });
  const reactions = createMemo(() => [...m().reactions.entries()].map(([emoji, set]) => ({ emoji, users: [...set.values()] })));
  const mine = () => m().authorId === client.user?.id;

  const react = async (emoji: string) => {
    const me = client.user?.id;
    if (!me) return;
    const set = m().reactions.get(emoji);
    if (IS_DEMO) {
      // local-only toggle for the demo
      if (set?.has(me)) {
        set.delete(me);
        if (set.size === 0) m().reactions.delete(emoji);
      } else {
        if (!set) {
          const { ReactiveSet } = await import("@solid-primitives/set");
          m().reactions.set(emoji, new ReactiveSet([me]));
        } else set.add(me);
      }
      return;
    }
    if (set?.has(me)) await m().unreact(emoji);
    else await m().react(emoji);
  };

  return (
    <div class="msg" classList={{ head: props.head, mine: mine(), mentioned: m().mentioned }}>
      <Show when={replyTo()}>
        {(r) => (
          <div class="msg-reply muted">
            <span class="msg-reply-curve" />
            <Avatar src={r().avatarURL} animatedSrc={r().animatedAvatarURL} size={16} fallback="?" />
            <span class="msg-reply-name display">{r().username ?? r().author?.displayName}</span>
            <span class="truncate">{r().content}</span>
          </div>
        )}
      </Show>

      <div class="msg-row">
        <Show
          when={props.head}
          fallback={<span class="msg-gutter mono muted">{fmtTime(m().createdAt)}</span>}
        >
          <Avatar
            src={m().avatarURL}
            animatedSrc={m().animatedAvatarURL}
            fallback={name().slice(0, 1)}
            size={40}
            presence={author()?.presence}
            class="msg-avatar"
          />
        </Show>

        <div class="msg-body grow">
          <Show when={props.head}>
            <div class="msg-meta row">
              <span class="msg-name display" style={{ color: colour() }}>
                {name()}
              </span>
              <Show when={author()?.bot && !m().masquerade}>
                <span class="pill" style={{ "font-size": "10px", padding: "1px 7px" }}>
                  bot
                </span>
              </Show>
              <span class="msg-time mono muted">{fmtDate(m().createdAt)}</span>
            </div>
          </Show>

          <div class="msg-content">
            <Show when={m().content}>
              <Markdown text={m().content} />
            </Show>
            <Show when={m().editedAt}>
              <span class="muted msg-edited">(edited)</span>
            </Show>
          </div>

          <Show when={m().attachments?.length}>
            <div class="msg-attachments">
              <For each={m().attachments}>
                {(f) => (
                  <Show
                    when={f.contentType?.startsWith("image/")}
                    fallback={
                      <a class="sticker-sm msg-file" href={f.originalUrl} target="_blank" rel="noopener">
                        📎 {f.filename} <span class="muted">{f.humanReadableSize}</span>
                      </a>
                    }
                  >
                    <img class="msg-image sticker-sm" src={f.createFileURL(true) ?? f.previewUrl} alt={f.filename} loading="lazy" />
                  </Show>
                )}
              </For>
            </div>
          </Show>

          <Show when={reactions().length > 0}>
            <div class="msg-reactions">
              <For each={reactions()}>
                {(r) => (
                  <button
                    class="reaction"
                    classList={{ mine: r.users.includes(client.user?.id ?? "") }}
                    onClick={() => react(r.emoji)}
                    title={r.users
                      .map((id) => client.users.get(id)?.displayName ?? "someone")
                      .join(", ")}
                  >
                    <span>{r.emoji}</span>
                    <span class="mono">{r.users.length}</span>
                  </button>
                )}
              </For>
            </div>
          </Show>
        </div>

        <div class="msg-actions sticker-sm">
          <For each={QUICK}>
            {(e) => (
              <button class="msg-action" onClick={() => react(e)} title={`react ${e}`}>
                {e}
              </button>
            )}
          </For>
          <Show when={mine()}>
            <button class="msg-action" title="delete" onClick={() => !IS_DEMO && m().delete()}>
              🗑
            </button>
          </Show>
        </div>
      </div>
    </div>
  );
}
