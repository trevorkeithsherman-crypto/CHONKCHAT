import { createMemo, For, Show } from "solid-js";
import { A, useParams } from "@solidjs/router";
import { client } from "../lib/client";
import { brand } from "../brand";
import { useUI } from "../lib/ui";
import Avatar from "./Avatar";
import "./ServerRail.css";

/** Left rail: home + list of dens (servers) as chunky stickers. */
export default function ServerRail() {
  const params = useParams();
  const ui = useUI();
  const servers = createMemo(() => client.servers.toList().sort((a, b) => a.name.localeCompare(b.name)));

  const dmUnread = createMemo(() =>
    client.channels.filter((c) => (c.type === "DirectMessage" || c.type === "Group") && c.unread).length,
  );

  return (
    <nav class="rail sticker">
      <A href="/app" class={`rail-item rail-home ${!params.server ? "active" : ""}`} title="home">
        <span class="rail-home-blob" />
        <Show when={dmUnread() > 0}>
          <span class="rail-badge">{dmUnread()}</span>
        </Show>
      </A>

      <div class="rail-sep" />

      <div class="rail-list">
        <For each={servers()}>
          {(s) => (
            <A
              href={`/app/den/${s.id}/${s.defaultChannel?.id ?? ""}`}
              class={`rail-item ${params.server === s.id ? "active" : ""}`}
              title={s.name}
            >
              <Avatar
                src={s.iconURL}
                animatedSrc={s.animatedIconURL}
                fallback={s.name.slice(0, 2)}
                size={48}
                shape="squircle"
              />
              <Show when={s.unread}>
                <span class="rail-dot" classList={{ mention: s.mentions.length > 0 }} />
              </Show>
            </A>
          )}
        </For>
      </div>

      <div class="rail-sep" />

      <button class="rail-item rail-add" title={`new ${brand.serverWord}`} onClick={() => alert("Creating dens is coming next 🛠️")}>
        +
      </button>
      <button class="rail-item rail-add" title="settings & themes" onClick={ui.openSettings}>
        ✦
      </button>
    </nav>
  );
}
