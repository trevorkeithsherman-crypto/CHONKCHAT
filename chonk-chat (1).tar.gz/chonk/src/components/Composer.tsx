import { createSignal } from "solid-js";
import type { Channel } from "stoat.js";
import { settings } from "../lib/settings";
import { IS_DEMO } from "../lib/client";
import "./Composer.css";

let typingTimer: number | undefined;

/** Message box with a very satisfying send button. */
export default function Composer(props: { channel: Channel; onSend: (text: string) => Promise<void> }) {
  const [text, setText] = createSignal("");
  const [busy, setBusy] = createSignal(false);
  const [popped, setPopped] = createSignal(false);
  let ta!: HTMLTextAreaElement;

  const autosize = () => {
    ta.style.height = "auto";
    ta.style.height = Math.min(ta.scrollHeight, 200) + "px";
  };

  const submit = async () => {
    const t = text().trim();
    if (!t || busy()) return;
    setBusy(true);
    try {
      await props.onSend(t);
      setText("");
      ta.style.height = "auto";
      setPopped(true);
      setTimeout(() => setPopped(false), 350);
      if (settings.sounds) blip();
    } finally {
      setBusy(false);
      ta.focus();
    }
  };

  const onKey = (e: KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  const onInput = () => {
    setText(ta.value);
    autosize();
    if (!IS_DEMO) {
      props.channel.startTyping();
      clearTimeout(typingTimer);
      typingTimer = window.setTimeout(() => props.channel.stopTyping(), 2500);
    }
  };

  return (
    <div class="composer">
      <div class="composer-box sticker-sm">
        <button class="composer-attach" title="attach (coming soon)">
          +
        </button>
        <textarea
          ref={ta}
          class="composer-input"
          rows={1}
          placeholder={`message ${props.channel.type === "DirectMessage" ? "@" : "#"}${props.channel.displayName ?? props.channel.name}`}
          value={text()}
          onInput={onInput}
          onKeyDown={onKey}
        />
        <button class="btn btn-accent composer-send" classList={{ popped: popped() }} onClick={submit} disabled={!text().trim() || busy()}>
          send
        </button>
      </div>
      <div class="composer-hint muted mono">enter to send · shift+enter for a new line</div>
    </div>
  );
}

/** A tiny synthesized "pop" — no audio file needed. */
function blip() {
  try {
    const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
    const ctx = new Ctx();
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.type = "sine";
    o.frequency.setValueAtTime(520, ctx.currentTime);
    o.frequency.exponentialRampToValueAtTime(880, ctx.currentTime + 0.08);
    g.gain.setValueAtTime(0.08, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.12);
    o.connect(g).connect(ctx.destination);
    o.start();
    o.stop(ctx.currentTime + 0.13);
  } catch {
    /* no audio, no problem */
  }
}
