import { createSignal, onCleanup } from "solid-js";
import { brand } from "../brand";
import "./Loading.css";

export default function Loading() {
  const [i, setI] = createSignal(0);
  const t = setInterval(() => setI((v) => (v + 1) % brand.loadingLines.length), 1400);
  onCleanup(() => clearInterval(t));
  return (
    <div class="loading wallpaper">
      <div class="loading-card sticker pop-in">
        <div class="loading-blob" />
        <div class="display loading-title">{brand.name}</div>
        <div class="muted loading-line">{brand.loadingLines[i()]}</div>
      </div>
    </div>
  );
}
